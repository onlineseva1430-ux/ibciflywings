import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages, language = "en", conversationId, sessionId } = await req.json();
    console.log("Meia chat request received:", { 
      messageCount: messages?.length, 
      language,
      conversationId,
      sessionId 
    });
    
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    
    if (!LOVABLE_API_KEY) {
      console.error("LOVABLE_API_KEY is not configured");
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    if (!messages || !Array.isArray(messages)) {
      console.error("Invalid messages format:", messages);
      throw new Error("Messages must be an array");
    }

    // Initialize Supabase client
    const supabase = createClient(SUPABASE_URL!, SUPABASE_SERVICE_ROLE_KEY!);

    // Get or create conversation
    let currentConversationId = conversationId;
    
    if (!currentConversationId) {
      // Create new conversation
      const authHeader = req.headers.get('authorization');
      let userId = null;
      
      // Try to get user ID from auth header
      if (authHeader) {
        try {
          const { data: { user } } = await supabase.auth.getUser(authHeader.replace('Bearer ', ''));
          userId = user?.id;
        } catch (e) {
          console.log("No authenticated user, using session ID");
        }
      }

      // Generate title from first message
      const title = messages[0]?.content.slice(0, 50) + (messages[0]?.content.length > 50 ? '...' : '');

      const { data: conversation, error: convError } = await supabase
        .from('conversations')
        .insert({
          user_id: userId,
          session_id: userId ? null : sessionId,
          title
        })
        .select()
        .single();

      if (convError) {
        console.error("Error creating conversation:", convError);
        throw new Error("Failed to create conversation");
      }

      currentConversationId = conversation.id;
      console.log("Created new conversation:", currentConversationId);
    } else {
      console.log("Using existing conversation:", currentConversationId);
    }

    // Save user message to database
    const lastMessage = messages[messages.length - 1];
    if (lastMessage?.role === "user") {
      const { error: msgError } = await supabase
        .from('conversation_messages')
        .insert({
          conversation_id: currentConversationId,
          role: lastMessage.role,
          content: lastMessage.content
        });

      if (msgError) {
        console.error("Error saving user message:", msgError);
      }
    }

    const languagePrompts = {
      en: "Respond in English.",
      hi: "Respond in Hindi (हिंदी में जवाब दें).",
      ta: "Respond in Tamil (தமிழில் பதிலளி).",
      te: "Respond in Telugu (తెలుగులో సమాధానం ఇవ్వండి).",
      kn: "Respond in Kannada (ಕನ್ನಡದಲ್ಲಿ ಉತ್ತರಿಸಿ).",
      ml: "Respond in Malayalam (മലയാളത്തിൽ മറുപടി നൽകുക).",
    };

    const languageInstruction = languagePrompts[language as keyof typeof languagePrompts] || languagePrompts.en;

    console.log("Calling AI gateway...");
    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "system",
            content: `You are Meia, a professional AI educational guide and mentor for IBCI Fly Wings - India's premier professional education platform.

Your Role & Communication Style:
- Professional academic advisor and expert guide
- Speak with confidence, clarity, and authority like an experienced educator
- Provide detailed, structured, and comprehensive explanations
- Use professional academic language - avoid casual expressions or playful terms
- Be supportive yet professional - like a respected professor or career counselor
- Give step-by-step guidance when explaining processes
- Anticipate follow-up questions and provide complete information upfront

Core Knowledge - IBCI Fly Wings Platform:

COURSES OFFERED:
1. CA (Chartered Accountancy) - Premier accounting qualification, comprehensive curriculum with expert faculty
2. CS (Company Secretary) - Corporate governance and compliance specialization
3. ACCA (Association of Chartered Certified Accountants) - Global accounting qualification
4. CMA (Certified Management Accountant) - Strategic management and cost accounting expertise
5. MBA (Master of Business Administration) - Advanced business management degree
6. Degree Programs - Undergraduate academic programs

PLATFORM FEATURES:
- Live Interactive Classes: Real-time sessions with expert faculty
- Recorded Sessions: 1000+ hours of video content available anytime via IBCI Play
- Expert Faculty: 15+ experienced professionals from industry
- Study Materials: Comprehensive notes, practice questions, and resources
- 100% Placement Assistance: Dedicated career support and job placement services
- Flexible Learning: Study at your own pace with recorded content
- Mobile & Web Access: Learn anywhere, anytime

SUCCESS METRICS:
- 5,000+ students successfully enrolled and trained
- 95% success rate in professional examinations
- Strong alumni network across industries
- Industry-recognized certifications and qualifications

CHARITY INITIATIVE:
- Program Name: "Give a Little, Change a Lot"
- Mission: Providing quality education to underprivileged students
- Every contribution helps deserving students access professional education
- Community-driven educational support program

ADMISSION PROCESS:
1. Browse available courses on the website
2. Fill out the placement/application form with your details
3. Our academic counselors will contact you within 24-48 hours
4. Receive course information, fee structure, and schedule details
5. Complete registration and begin your learning journey

WEBSITE NAVIGATION:
- Home: Overview and key statistics
- Courses: Detailed course information and enrollment
- Live Classes: Schedule and access to live sessions
- Contact: Reach out to our team for queries
- Sign Up: Registration for new students
- Admin: Portal for administrative functions

Your Responsibilities:
1. Guide visitors through website sections and explain each feature
2. Provide detailed course information including eligibility, duration, and career prospects
3. Explain the admission process step-by-step
4. Answer questions about fees, schedules, faculty, and placement support
5. Help users navigate to specific pages or information
6. Offer educational guidance and career advice related to professional courses
7. Explain IBCI Play features and how to access video content
8. Provide information about the charity program and how to contribute

Response Guidelines:
- Start with a clear, direct answer to the user's question
- Provide context and additional relevant information
- Use structured formatting (numbered lists, bullet points) for clarity
- If information is not available, guide users to contact support: contact@ibciflywings.com
- Remember conversation context and refer back to previous discussions
- Anticipate related questions and address them proactively
- End with: "Is there anything specific you'd like to know more about?"

${languageInstruction}

Maintain professionalism, accuracy, and helpfulness in every interaction. Your goal is to ensure every visitor receives expert guidance and finds exactly what they need on the IBCI Fly Wings platform.`
          },
          ...messages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      console.error("AI gateway response not OK:", response.status, response.statusText);
      
      if (response.status === 429) {
        console.error("Rate limit exceeded");
        return new Response(
          JSON.stringify({ error: "I'm a bit overwhelmed right now! Please try again in a moment." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        console.error("Payment required");
        return new Response(
          JSON.stringify({ error: "Service temporarily unavailable. Please contact support." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const errorText = await response.text();
      console.error("AI gateway error details:", response.status, errorText);
      return new Response(
        JSON.stringify({ error: "I'm having trouble connecting right now. Please try again!" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("AI gateway response successful, streaming...");
    
    // Create a transform stream to save assistant response
    const { readable, writable } = new TransformStream();
    const writer = writable.getWriter();
    const reader = response.body!.getReader();
    let assistantMessage = "";

    // Process stream and save to database
    (async () => {
      try {
        const decoder = new TextDecoder();
        while (true) {
          const { done, value } = await reader.read();
          if (done) {
            // Save complete assistant message
            if (assistantMessage) {
              await supabase
                .from('conversation_messages')
                .insert({
                  conversation_id: currentConversationId,
                  role: 'assistant',
                  content: assistantMessage
                });
            }
            await writer.close();
            break;
          }

          // Parse SSE data to extract assistant message
          const chunk = decoder.decode(value);
          const lines = chunk.split('\n');
          for (const line of lines) {
            if (line.startsWith('data: ')) {
              const jsonStr = line.slice(6).trim();
              if (jsonStr && jsonStr !== '[DONE]') {
                try {
                  const parsed = JSON.parse(jsonStr);
                  const content = parsed.choices?.[0]?.delta?.content;
                  if (content) {
                    assistantMessage += content;
                  }
                } catch (e) {
                  // Ignore parse errors for incomplete chunks
                }
              }
            }
          }

          await writer.write(value);
        }
      } catch (error) {
        console.error("Stream processing error:", error);
        await writer.abort(error);
      }
    })();

    // Return stream with conversation ID header
    return new Response(readable, {
      headers: { 
        ...corsHeaders, 
        "Content-Type": "text/event-stream",
        "X-Conversation-Id": currentConversationId
      },
    });
  } catch (error) {
    console.error("Chat error details:", error);
    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : "I encountered an unexpected error. Please try again!" 
      }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
