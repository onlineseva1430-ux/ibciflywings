-- Create a table for CMS/editable pages
CREATE TABLE public.cms_pages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  subtitle TEXT,
  content TEXT,
  meta_description TEXT,
  image_url TEXT,
  is_published BOOLEAN DEFAULT true,
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.cms_pages ENABLE ROW LEVEL SECURITY;

-- Anyone can view published pages
CREATE POLICY "Anyone can view published pages"
ON public.cms_pages
FOR SELECT
USING (is_published = true);

-- Admins can manage all pages
CREATE POLICY "Admins can manage pages"
ON public.cms_pages
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

-- Add trigger for updated_at
CREATE TRIGGER update_cms_pages_updated_at
BEFORE UPDATE ON public.cms_pages
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default Vibra pages
INSERT INTO public.cms_pages (slug, title, subtitle, content, display_order) VALUES
('about-vibra', 'About Vibra Music', 'A platform for artists, creators, and music lovers', 'Vibra Music is a modern streaming platform designed to help independent artists share their music with the world.\n\n## Why Vibra is Unique\nWe provide a dedicated space for upcoming talents to showcase their work.\n\n## Our Mission\nSupporting independent artists and upcoming talents through our collaboration with IBCI Fly Wings Institute.', 1),
('terms', 'Terms & Conditions', 'Usage rules and policies', '## Usage Rules\nPlease read these terms carefully before using Vibra Music.\n\n## Content Upload Policy\nAll uploaded content must be original or properly licensed.\n\n## Artist & User Policies\nUsers must respect copyright and community guidelines.', 2),
('privacy', 'Privacy Policy', 'How we handle your data', '## User Data Usage\nWe collect minimal data necessary to provide our services.\n\n## Content Handling\nYour uploaded content remains your property.\n\n## Audio/Video Uploads\nFiles are securely stored and protected.', 3),
('help', 'Help & Support', 'Get help with Vibra Music', '## How to Upload Music\n1. Create an account\n2. Go to upload section\n3. Select your files\n4. Add metadata and publish\n\n## How to Create Playlists\nUse the playlist feature to organize your favorites.\n\n## How to Report Issues\nContact our support team through the contact form.\n\n## Contact Support\nEmail: support@vibra.com', 4),
('partners', 'Our Partners – Vibra × IBCI', 'A powerful collaboration for artists and education', '## Vibra Music\nA platform for artists, creators, and music lovers to upload, share, and enjoy a modern streaming experience.\n\n## IBCI Fly Wings Institute\nAn educational platform that supports Vibra''s mission by:\n- Providing talents\n- Offering charity programs for underprivileged students\n- Supporting artistic growth\n\n## Our Joint Mission\nTogether, we empower students and creators to achieve their dreams through music and education.\n\n## Opportunities\nStudents and creators can participate in workshops, talent showcases, and collaborative projects.', 5);