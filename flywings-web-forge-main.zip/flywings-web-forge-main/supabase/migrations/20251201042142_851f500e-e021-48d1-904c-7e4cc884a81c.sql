-- Create enum for user roles
CREATE TYPE public.app_role AS ENUM ('admin', 'user');

-- Create user_roles table
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(user_id, role)
);

-- Enable RLS
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Create security definer function to check roles
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

-- RLS policies for user_roles
CREATE POLICY "Users can view their own roles"
ON public.user_roles FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all roles"
ON public.user_roles FOR ALL
USING (public.has_role(auth.uid(), 'admin'));

-- Create applications table (for general applications)
CREATE TABLE public.applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  course TEXT NOT NULL,
  message TEXT,
  status TEXT DEFAULT 'pending',
  documents JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.applications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view all applications"
ON public.applications FOR SELECT
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update applications"
ON public.applications FOR UPDATE
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Anyone can submit applications"
ON public.applications FOR INSERT
WITH CHECK (true);

-- Create placement_applications table
CREATE TABLE public.placement_applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  qualification TEXT NOT NULL,
  experience TEXT,
  resume_url TEXT,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.placement_applications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view all placement applications"
ON public.placement_applications FOR SELECT
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update placement applications"
ON public.placement_applications FOR UPDATE
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Anyone can submit placement applications"
ON public.placement_applications FOR INSERT
WITH CHECK (true);

-- Create homepage_stats table
CREATE TABLE public.homepage_stats (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  students_enrolled INTEGER DEFAULT 5000,
  expert_faculty INTEGER DEFAULT 15,
  success_rate INTEGER DEFAULT 95,
  student_rating INTEGER DEFAULT 45,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.homepage_stats ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Everyone can view stats"
ON public.homepage_stats FOR SELECT
USING (true);

CREATE POLICY "Admins can update stats"
ON public.homepage_stats FOR ALL
USING (public.has_role(auth.uid(), 'admin'));

-- Insert initial stats
INSERT INTO public.homepage_stats (students_enrolled, expert_faculty, success_rate, student_rating)
VALUES (5000, 15, 95, 45);

-- Create student_testimonials table
CREATE TABLE public.student_testimonials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_name TEXT NOT NULL,
  student_image TEXT,
  story TEXT NOT NULL,
  rating INTEGER CHECK (rating >= 1 AND rating <= 5),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.student_testimonials ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Everyone can view active testimonials"
ON public.student_testimonials FOR SELECT
USING (is_active = true);

CREATE POLICY "Admins can manage testimonials"
ON public.student_testimonials FOR ALL
USING (public.has_role(auth.uid(), 'admin'));

-- Create placement_info table for page control
CREATE TABLE public.placement_info (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  is_active BOOLEAN DEFAULT true,
  title TEXT DEFAULT 'Placement Assistance at IBCI Fly Wings',
  description TEXT DEFAULT 'Our dedicated placement cell helps students secure positions in top organizations.',
  content TEXT,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.placement_info ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Everyone can view placement info"
ON public.placement_info FOR SELECT
USING (is_active = true);

CREATE POLICY "Admins can manage placement info"
ON public.placement_info FOR ALL
USING (public.has_role(auth.uid(), 'admin'));

-- Insert initial placement info
INSERT INTO public.placement_info (title, content)
VALUES (
  'Placement Assistance at IBCI Fly Wings',
  'We provide comprehensive placement support including resume building, interview preparation, and direct connections with leading companies in the industry.'
);

-- Create trigger for updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_applications_updated_at BEFORE UPDATE ON public.applications
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_placement_applications_updated_at BEFORE UPDATE ON public.placement_applications
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_homepage_stats_updated_at BEFORE UPDATE ON public.homepage_stats
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_student_testimonials_updated_at BEFORE UPDATE ON public.student_testimonials
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_placement_info_updated_at BEFORE UPDATE ON public.placement_info
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();