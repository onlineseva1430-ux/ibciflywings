-- Create site content table for admin editing
CREATE TABLE public.site_content (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  section_key TEXT NOT NULL UNIQUE,
  title TEXT,
  subtitle TEXT,
  content TEXT,
  image_url TEXT,
  metadata JSONB DEFAULT '{}',
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_by UUID REFERENCES auth.users(id)
);

-- Create faculty members table
CREATE TABLE public.faculty_members (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  designation TEXT NOT NULL,
  department TEXT,
  qualifications TEXT,
  experience_years INTEGER,
  bio TEXT,
  image_url TEXT,
  email TEXT,
  linkedin_url TEXT,
  specializations TEXT[],
  display_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create placement records table
CREATE TABLE public.placement_records (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  student_name TEXT NOT NULL,
  course TEXT NOT NULL,
  company_name TEXT NOT NULL,
  designation TEXT,
  package_lpa DECIMAL(10,2),
  year INTEGER NOT NULL,
  image_url TEXT,
  testimonial TEXT,
  linkedin_url TEXT,
  is_featured BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create gallery images table
CREATE TABLE public.gallery_images (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  image_url TEXT NOT NULL,
  category TEXT DEFAULT 'general',
  display_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.site_content ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.faculty_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.placement_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gallery_images ENABLE ROW LEVEL SECURITY;

-- Public read access for all content tables
CREATE POLICY "Anyone can view site content" ON public.site_content FOR SELECT USING (true);
CREATE POLICY "Anyone can view faculty" ON public.faculty_members FOR SELECT USING (is_active = true);
CREATE POLICY "Anyone can view placements" ON public.placement_records FOR SELECT USING (true);
CREATE POLICY "Anyone can view gallery" ON public.gallery_images FOR SELECT USING (is_active = true);

-- Admin write access
CREATE POLICY "Admins can manage site content" ON public.site_content FOR ALL USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can manage faculty" ON public.faculty_members FOR ALL USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can manage placements" ON public.placement_records FOR ALL USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can manage gallery" ON public.gallery_images FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- Create triggers for updated_at
CREATE TRIGGER update_site_content_updated_at BEFORE UPDATE ON public.site_content FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_faculty_updated_at BEFORE UPDATE ON public.faculty_members FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default site content
INSERT INTO public.site_content (section_key, title, subtitle, content) VALUES
('hero', 'Your Gateway to Professional Excellence', 'IBCI Fly Wings – Rise Beyond Limits', 'Master CA, CMA, ACCA, CS, MBA & Degree programs with India''s leading faculty. Learn anytime, anywhere.'),
('about', 'About IBCI Fly Wings', 'Premier Online Learning Platform', 'IBCI Fly Wings is a premier online learning platform dedicated to transforming the way you prepare for your dream professional qualifications.'),
('mission', 'Our Mission', NULL, 'To empower students with knowledge, confidence, and skills to crack any professional exam and become leaders in their chosen field.'),
('vision', 'Our Vision', NULL, 'To be the leading institute for professional education, recognized globally for our innovative teaching methods and student success rates.'),
('stats', 'Our Impact', 'Numbers That Speak', '{"students": 5000, "faculty": 15, "success_rate": 95, "rating": 4.9}');

-- Insert sample faculty
INSERT INTO public.faculty_members (name, designation, department, qualifications, experience_years, bio, specializations, display_order) VALUES
('Dr. Rajesh Kumar', 'Senior Faculty - CA', 'Chartered Accountancy', 'CA, PhD in Commerce', 15, 'Expert in Financial Reporting and Auditing with 15+ years of teaching experience.', ARRAY['Financial Reporting', 'Auditing', 'Taxation'], 1),
('Prof. Meera Sharma', 'Head of CMA', 'Cost Management', 'CMA, MBA Finance', 12, 'Specializes in Cost Accounting and Management with industry experience.', ARRAY['Cost Accounting', 'Management Accounting', 'Budgeting'], 2),
('CA Vikram Singh', 'ACCA Faculty', 'ACCA', 'CA, ACCA, CFA', 10, 'International accounting expert with global certification experience.', ARRAY['International Accounting', 'Financial Analysis', 'IFRS'], 3);

-- Insert sample placement records
INSERT INTO public.placement_records (student_name, course, company_name, designation, package_lpa, year, testimonial, is_featured) VALUES
('Priya Sharma', 'CA Final', 'Deloitte', 'Associate Consultant', 12.5, 2024, 'IBCI Fly Wings transformed my preparation journey!', true),
('Rahul Kumar', 'CMA', 'KPMG', 'Financial Analyst', 10.0, 2024, 'The faculty support was exceptional throughout.', true),
('Anita Patel', 'ACCA', 'EY', 'Senior Associate', 15.0, 2023, 'Best investment in my career!', true);