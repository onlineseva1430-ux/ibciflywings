import { createContext, useContext, useState, ReactNode } from "react";

interface MeiaContextType {
  isChatOpen: boolean;
  openChat: () => void;
  closeChat: () => void;
  language: string;
  setLanguage: (lang: string) => void;
  readContent: (content: string) => void;
}

const MeiaContext = createContext<MeiaContextType | undefined>(undefined);

export const MeiaProvider = ({ children }: { children: ReactNode }) => {
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [language, setLanguage] = useState("en");

  const openChat = () => setIsChatOpen(true);
  const closeChat = () => setIsChatOpen(false);

  const readContent = (content: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(content);
      utterance.rate = 0.9;
      utterance.pitch = 1.1;
      utterance.volume = 1;
      
      const voices = window.speechSynthesis.getVoices();
      const femaleVoice = voices.find(voice => 
        voice.name.includes('Female') || voice.name.includes('Samantha') || voice.name.includes('Victoria')
      ) || voices[0];
      
      if (femaleVoice) {
        utterance.voice = femaleVoice;
      }

      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <MeiaContext.Provider value={{ isChatOpen, openChat, closeChat, language, setLanguage, readContent }}>
      {children}
    </MeiaContext.Provider>
  );
};

export const useMeia = () => {
  const context = useContext(MeiaContext);
  if (!context) {
    throw new Error("useMeia must be used within MeiaProvider");
  }
  return context;
};
