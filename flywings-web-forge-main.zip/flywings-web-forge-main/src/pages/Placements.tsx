import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Briefcase, TrendingUp, Building2, Users, IndianRupee, Linkedin, Quote } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import placementsHero from "@/assets/placements-hero.jpg";

interface PlacementRecord {
  id: string;
  student_name: string;
  course: string;
  company_name: string;
  designation: string;
  package_lpa: number;
  year: number;
  image_url: string;
  testimonial: string;
  linkedin_url: string;
  is_featured: boolean;
}

export default function Placements() {
  const [placements, setPlacements] = useState<PlacementRecord[]>([]);
  const [featuredPlacements, setFeaturedPlacements] = useState<PlacementRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPlacements = async () => {
      const { data, error } = await supabase
        .from("placement_records")
        .select("*")
        .order("year", { ascending: false });
      
      if (data) {
        setPlacements(data);
        setFeaturedPlacements(data.filter(p => p.is_featured));
      }
      setLoading(false);
    };
    fetchPlacements();
  }, []);

  const stats = [
    { icon: Users, value: "500+", label: "Students Placed" },
    { icon: Building2, value: "100+", label: "Partner Companies" },
    { icon: IndianRupee, value: "15 LPA", label: "Highest Package" },
    { icon: TrendingUp, value: "95%", label: "Placement Rate" },
  ];

  const topRecruiters = [
    "Deloitte", "KPMG", "EY", "PwC", "Grant Thornton", "BDO",
    "Wipro", "TCS", "Infosys", "Accenture", "HCL", "Cognizant"
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src={placementsHero} 
            alt="Placement Success" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-primary/95 via-primary/85 to-primary/70"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Badge variant="secondary" className="mb-6 text-base px-6 py-2">
            Career Success Stories
          </Badge>
          <h1 className="text-5xl md:text-6xl font-bold text-primary-foreground mb-6">
            Placement Excellence
          </h1>
          <p className="text-xl md:text-2xl text-primary-foreground/90 max-w-3xl leading-relaxed">
            Our students are placed in top companies across India and globally. Your success is our pride.
          </p>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <Card key={index} className="text-center border-none shadow-lg bg-gradient-to-br from-background to-muted/50">
                <CardContent className="pt-6">
                  <div className="mx-auto w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                    <stat.icon className="h-7 w-7 text-primary" />
                  </div>
                  <div className="text-3xl font-bold text-primary mb-1">{stat.value}</div>
                  <div className="text-muted-foreground text-sm">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Placements */}
      <section className="py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Featured Success Stories</h2>
            <p className="text-xl text-muted-foreground">
              Celebrating our students' achievements and career milestones
            </p>
          </div>

          {loading ? (
            <div className="grid md:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-6">
                    <div className="h-6 bg-muted rounded mb-2"></div>
                    <div className="h-4 bg-muted rounded w-2/3"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredPlacements.map((placement) => (
                <Card key={placement.id} className="overflow-hidden hover:shadow-xl transition-all group">
                  <CardHeader className="bg-gradient-to-br from-primary/5 to-accent/5">
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center flex-shrink-0">
                        {placement.image_url ? (
                          <img 
                            src={placement.image_url} 
                            alt={placement.student_name}
                            className="w-full h-full rounded-full object-cover"
                          />
                        ) : (
                          <span className="text-xl font-bold text-primary-foreground">
                            {placement.student_name.split(' ').map(n => n[0]).join('')}
                          </span>
                        )}
                      </div>
                      <div>
                        <CardTitle className="text-lg">{placement.student_name}</CardTitle>
                        <CardDescription>{placement.course}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="space-y-4 pt-4">
                    <div className="flex items-center gap-2">
                      <Building2 className="h-5 w-5 text-primary" />
                      <span className="font-semibold">{placement.company_name}</span>
                    </div>
                    
                    {placement.designation && (
                      <div className="flex items-center gap-2">
                        <Briefcase className="h-5 w-5 text-muted-foreground" />
                        <span>{placement.designation}</span>
                      </div>
                    )}
                    
                    {placement.package_lpa && (
                      <Badge variant="secondary" className="text-sm">
                        ₹{placement.package_lpa} LPA
                      </Badge>
                    )}
                    
                    {placement.testimonial && (
                      <div className="relative bg-muted/50 rounded-lg p-4 mt-4">
                        <Quote className="h-6 w-6 text-primary/20 absolute top-2 left-2" />
                        <p className="text-sm text-muted-foreground italic pl-6">
                          "{placement.testimonial}"
                        </p>
                      </div>
                    )}
                    
                    <div className="flex items-center justify-between pt-2">
                      <span className="text-sm text-muted-foreground">
                        Batch of {placement.year}
                      </span>
                      {placement.linkedin_url && (
                        <Button variant="ghost" size="sm" asChild>
                          <a href={placement.linkedin_url} target="_blank" rel="noopener noreferrer">
                            <Linkedin className="h-4 w-4" />
                          </a>
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Top Recruiters */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Top Recruiters</h2>
            <p className="text-xl text-muted-foreground">
              Leading companies that hire our students
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-4">
            {topRecruiters.map((company, index) => (
              <div
                key={index}
                className="px-6 py-3 bg-muted/50 rounded-lg text-center hover:bg-primary hover:text-primary-foreground transition-colors cursor-default"
              >
                <span className="font-medium">{company}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-r from-primary to-accent text-primary-foreground">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Start Your Success Story</h2>
          <p className="text-xl text-primary-foreground/90 mb-8">
            Join IBCI Fly Wings and take the first step towards a rewarding career.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" asChild>
              <a href="/courses">Explore Courses</a>
            </Button>
            <Button size="lg" variant="outline" className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary" asChild>
              <a href="/contact">Contact Us</a>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}