import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Target, Eye, Award, Users, BookOpen, Star, CheckCircle2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import aboutBuilding from "@/assets/about-building.jpg";

interface SiteContent {
  section_key: string;
  title: string;
  subtitle: string;
  content: string;
  image_url: string;
}

export default function About() {
  const [content, setContent] = useState<Record<string, SiteContent>>({});

  useEffect(() => {
    const fetchContent = async () => {
      const { data } = await supabase
        .from("site_content")
        .select("*")
        .in("section_key", ["about", "mission", "vision", "stats"]);
      
      if (data) {
        const contentMap = data.reduce((acc, item) => {
          acc[item.section_key] = item;
          return acc;
        }, {} as Record<string, SiteContent>);
        setContent(contentMap);
      }
    };
    fetchContent();
  }, []);

  const values = [
    { icon: Award, title: "Excellence", description: "We strive for the highest standards in education delivery" },
    { icon: Users, title: "Student-Centric", description: "Every decision is made keeping student success in mind" },
    { icon: BookOpen, title: "Innovation", description: "Embracing new teaching methodologies and technologies" },
    { icon: Star, title: "Integrity", description: "Maintaining ethical standards in all our practices" },
  ];

  const highlights = [
    "15+ Years of Excellence in Professional Education",
    "Expert Faculty with Industry Experience",
    "Comprehensive Study Materials & Resources",
    "Live Interactive Classes & Recorded Sessions",
    "Regular Mock Tests & Performance Analysis",
    "Dedicated Placement Assistance",
    "Flexible Learning Options",
    "Affordable Course Fees with EMI Options",
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src={aboutBuilding} 
            alt="IBCI Campus" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-primary/95 via-primary/85 to-primary/70"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Badge variant="secondary" className="mb-6 text-base px-6 py-2">
            Established Excellence
          </Badge>
          <h1 className="text-5xl md:text-6xl font-bold text-primary-foreground mb-6">
            {content.about?.title || "About IBCI Fly Wings"}
          </h1>
          <p className="text-xl md:text-2xl text-primary-foreground/90 max-w-3xl leading-relaxed">
            {content.about?.content || "A premier online learning platform dedicated to transforming the way you prepare for your dream professional qualifications."}
          </p>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Our Story</h2>
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                IBCI Fly Wings was founded with a vision to democratize professional education and make quality learning accessible to every aspiring professional across India and beyond.
              </p>
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                What started as a small initiative has grown into a comprehensive learning platform serving thousands of students preparing for CA, CMA, ACCA, CS, MBA, and various degree programs.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Our commitment to excellence, innovative teaching methods, and student-centric approach has helped us achieve remarkable success rates and build a community of successful professionals.
              </p>
            </div>
            <div className="relative">
              <div className="bg-gradient-to-br from-primary/10 to-accent/10 rounded-2xl p-8">
                <blockquote className="text-2xl font-serif italic text-primary mb-4">
                  "Your wings already exist. All you have to do is fly."
                </blockquote>
                <p className="text-muted-foreground">— IBCI FLY WINGS Philosophy</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="border-l-4 border-l-primary shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="flex items-center gap-4">
                  <div className="p-3 rounded-full bg-primary/10">
                    <Target className="h-8 w-8 text-primary" />
                  </div>
                  <CardTitle className="text-2xl">{content.mission?.title || "Our Mission"}</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-lg leading-relaxed">
                  {content.mission?.content || "To empower students with knowledge, confidence, and skills to crack any professional exam and become leaders in their chosen field. We are committed to fostering excellence, integrity, and innovation in professional education."}
                </p>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-accent shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="flex items-center gap-4">
                  <div className="p-3 rounded-full bg-accent/10">
                    <Eye className="h-8 w-8 text-accent" />
                  </div>
                  <CardTitle className="text-2xl">{content.vision?.title || "Our Vision"}</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-lg leading-relaxed">
                  {content.vision?.content || "To be the leading institute for professional education, recognized globally for our innovative teaching methods, student success rates, and contribution to developing ethical and competent professionals."}
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Core Values</h2>
            <p className="text-xl text-muted-foreground">The principles that guide everything we do</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-all hover:-translate-y-1">
                <CardContent className="pt-8 pb-6">
                  <div className="mx-auto w-16 h-16 rounded-full bg-gradient-to-br from-primary/10 to-accent/10 flex items-center justify-center mb-4">
                    <value.icon className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">{value.title}</h3>
                  <p className="text-muted-foreground">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-gradient-to-br from-primary via-primary to-accent text-primary-foreground">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose IBCI Fly Wings?</h2>
            <p className="text-xl text-primary-foreground/80">What sets us apart from the rest</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {highlights.map((highlight, index) => (
              <div 
                key={index} 
                className="flex items-start gap-3 bg-primary-foreground/10 backdrop-blur-sm rounded-lg p-4 hover:bg-primary-foreground/20 transition-colors"
              >
                <CheckCircle2 className="h-6 w-6 text-accent flex-shrink-0 mt-0.5" />
                <span className="text-primary-foreground/90">{highlight}</span>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}