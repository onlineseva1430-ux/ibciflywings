import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { 
  LayoutDashboard, 
  FileText,
  Users,
  Briefcase,
  Image,
  Settings,
  Save,
  Plus,
  Trash2,
  Edit2,
  MessageSquare,
  BarChart3,
  Music
} from "lucide-react";
import { AdminPagesTab } from "@/components/AdminPagesTab";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";

interface SiteContent {
  id: string;
  section_key: string;
  title: string;
  subtitle: string;
  content: string;
  image_url: string;
}

interface FacultyMember {
  id: string;
  name: string;
  designation: string;
  department: string;
  qualifications: string;
  experience_years: number;
  bio: string;
  image_url: string;
  is_active: boolean;
}

interface PlacementRecord {
  id: string;
  student_name: string;
  course: string;
  company_name: string;
  designation: string;
  package_lpa: number;
  year: number;
  is_featured: boolean;
}

const ADMIN_PASSWORD = "admin123456";

export default function Admin() {
  const { toast } = useToast();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [siteContent, setSiteContent] = useState<SiteContent[]>([]);
  const [faculty, setFaculty] = useState<FacultyMember[]>([]);
  const [placements, setPlacements] = useState<PlacementRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingContent, setEditingContent] = useState<SiteContent | null>(null);
  const [editingFaculty, setEditingFaculty] = useState<FacultyMember | null>(null);
  const [editingPlacement, setEditingPlacement] = useState<PlacementRecord | null>(null);

  const [analytics] = useState({
    totalChats: 1247,
    activeUsers: 89,
    avgResponseTime: "2.3s",
    satisfactionRate: "94%"
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      setIsAuthenticated(true);
      setPasswordError("");
    } else {
      setPasswordError("Incorrect password");
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      fetchAllData();
    }
  }, [isAuthenticated]);

  const fetchAllData = async () => {
    setLoading(true);
    const [contentRes, facultyRes, placementsRes] = await Promise.all([
      supabase.from("site_content").select("*"),
      supabase.from("faculty_members").select("*").order("display_order"),
      supabase.from("placement_records").select("*").order("year", { ascending: false })
    ]);

    if (contentRes.data) setSiteContent(contentRes.data);
    if (facultyRes.data) setFaculty(facultyRes.data);
    if (placementsRes.data) setPlacements(placementsRes.data);
    setLoading(false);
  };

  const saveContent = async (content: SiteContent) => {
    const { error } = await supabase
      .from("site_content")
      .update({
        title: content.title,
        subtitle: content.subtitle,
        content: content.content,
        image_url: content.image_url
      })
      .eq("id", content.id);

    if (error) {
      toast({ title: "Error", description: "Failed to save content", variant: "destructive" });
    } else {
      toast({ title: "Success", description: "Content updated successfully" });
      fetchAllData();
      setEditingContent(null);
    }
  };

  const saveFaculty = async (member: FacultyMember) => {
    if (member.id) {
      const { error } = await supabase
        .from("faculty_members")
        .update({
          name: member.name,
          designation: member.designation,
          department: member.department,
          qualifications: member.qualifications,
          experience_years: member.experience_years,
          bio: member.bio,
          image_url: member.image_url,
          is_active: member.is_active
        })
        .eq("id", member.id);
      
      if (error) {
        toast({ title: "Error", description: "Failed to update faculty", variant: "destructive" });
      } else {
        toast({ title: "Success", description: "Faculty updated successfully" });
      }
    } else {
      const { error } = await supabase
        .from("faculty_members")
        .insert([{
          name: member.name,
          designation: member.designation,
          department: member.department,
          qualifications: member.qualifications,
          experience_years: member.experience_years,
          bio: member.bio,
          image_url: member.image_url,
          is_active: member.is_active
        }]);
      
      if (error) {
        toast({ title: "Error", description: "Failed to add faculty", variant: "destructive" });
      } else {
        toast({ title: "Success", description: "Faculty added successfully" });
      }
    }
    fetchAllData();
    setEditingFaculty(null);
  };

  const deleteFaculty = async (id: string) => {
    const { error } = await supabase.from("faculty_members").delete().eq("id", id);
    if (!error) {
      toast({ title: "Success", description: "Faculty deleted" });
      fetchAllData();
    }
  };

  const savePlacement = async (record: PlacementRecord) => {
    if (record.id) {
      const { error } = await supabase
        .from("placement_records")
        .update({
          student_name: record.student_name,
          course: record.course,
          company_name: record.company_name,
          designation: record.designation,
          package_lpa: record.package_lpa,
          year: record.year,
          is_featured: record.is_featured
        })
        .eq("id", record.id);
      
      if (!error) toast({ title: "Success", description: "Placement updated" });
    } else {
      const { error } = await supabase
        .from("placement_records")
        .insert([{
          student_name: record.student_name,
          course: record.course,
          company_name: record.company_name,
          designation: record.designation,
          package_lpa: record.package_lpa,
          year: record.year,
          is_featured: record.is_featured
        }]);
      
      if (!error) toast({ title: "Success", description: "Placement added" });
    }
    fetchAllData();
    setEditingPlacement(null);
  };

  const deletePlacement = async (id: string) => {
    const { error } = await supabase.from("placement_records").delete().eq("id", id);
    if (!error) {
      toast({ title: "Success", description: "Placement deleted" });
      fetchAllData();
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-muted/30 via-background to-muted/30">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Admin Access</CardTitle>
            <CardDescription>Enter password to access the admin portal</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter admin password"
                />
                {passwordError && (
                  <p className="text-sm text-destructive">{passwordError}</p>
                )}
              </div>
              <Button type="submit" className="w-full">
                Access Dashboard
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8 px-4 bg-gradient-to-br from-muted/30 via-background to-muted/30">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-primary mb-2">Admin Dashboard</h1>
          <p className="text-muted-foreground">Manage website content, faculty, and placements</p>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 md:grid-cols-7 gap-2 h-auto p-2">
            <TabsTrigger value="overview" className="flex items-center gap-2 py-3">
              <LayoutDashboard className="h-4 w-4" />
              <span className="hidden sm:inline">Overview</span>
            </TabsTrigger>
            <TabsTrigger value="content" className="flex items-center gap-2 py-3">
              <FileText className="h-4 w-4" />
              <span className="hidden sm:inline">Content</span>
            </TabsTrigger>
            <TabsTrigger value="pages" className="flex items-center gap-2 py-3">
              <Music className="h-4 w-4" />
              <span className="hidden sm:inline">Vibra Pages</span>
            </TabsTrigger>
            <TabsTrigger value="faculty" className="flex items-center gap-2 py-3">
              <Users className="h-4 w-4" />
              <span className="hidden sm:inline">Faculty</span>
            </TabsTrigger>
            <TabsTrigger value="placements" className="flex items-center gap-2 py-3">
              <Briefcase className="h-4 w-4" />
              <span className="hidden sm:inline">Placements</span>
            </TabsTrigger>
            <TabsTrigger value="meia" className="flex items-center gap-2 py-3">
              <MessageSquare className="h-4 w-4" />
              <span className="hidden sm:inline">MEIA</span>
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2 py-3">
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">Analytics</span>
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Content Sections</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{siteContent.length}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Faculty Members</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{faculty.length}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Placement Records</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{placements.length}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Active Chats</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{analytics.activeUsers}</div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="flex flex-wrap gap-4">
                <Button onClick={() => setEditingFaculty({ id: '', name: '', designation: '', department: '', qualifications: '', experience_years: 0, bio: '', image_url: '', is_active: true })}>
                  <Plus className="h-4 w-4 mr-2" /> Add Faculty
                </Button>
                <Button onClick={() => setEditingPlacement({ id: '', student_name: '', course: '', company_name: '', designation: '', package_lpa: 0, year: new Date().getFullYear(), is_featured: false })}>
                  <Plus className="h-4 w-4 mr-2" /> Add Placement
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Content Tab */}
          <TabsContent value="content" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Site Content Management</CardTitle>
                <CardDescription>Edit hero, about, mission, vision and other content sections</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {siteContent.map((content) => (
                    <div key={content.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <Badge variant="outline" className="mb-2">{content.section_key}</Badge>
                        <h4 className="font-medium">{content.title || 'No title'}</h4>
                        <p className="text-sm text-muted-foreground line-clamp-1">{content.content}</p>
                      </div>
                      <Button variant="outline" size="sm" onClick={() => setEditingContent(content)}>
                        <Edit2 className="h-4 w-4 mr-2" /> Edit
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Vibra Pages Tab */}
          <TabsContent value="pages" className="space-y-6">
            <AdminPagesTab />
          </TabsContent>

          {/* Faculty Tab */}
          <TabsContent value="faculty" className="space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Faculty Management</CardTitle>
                  <CardDescription>Add, edit, or remove faculty members</CardDescription>
                </div>
                <Button onClick={() => setEditingFaculty({ id: '', name: '', designation: '', department: '', qualifications: '', experience_years: 0, bio: '', image_url: '', is_active: true })}>
                  <Plus className="h-4 w-4 mr-2" /> Add Faculty
                </Button>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Designation</TableHead>
                      <TableHead>Department</TableHead>
                      <TableHead>Experience</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {faculty.map((member) => (
                      <TableRow key={member.id}>
                        <TableCell className="font-medium">{member.name}</TableCell>
                        <TableCell>{member.designation}</TableCell>
                        <TableCell>{member.department}</TableCell>
                        <TableCell>{member.experience_years} yrs</TableCell>
                        <TableCell>
                          <Badge variant={member.is_active ? "default" : "secondary"}>
                            {member.is_active ? "Active" : "Inactive"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="ghost" size="sm" onClick={() => setEditingFaculty(member)}>
                              <Edit2 className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => deleteFaculty(member.id)}>
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Placements Tab */}
          <TabsContent value="placements" className="space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Placement Records</CardTitle>
                  <CardDescription>Manage student placement data</CardDescription>
                </div>
                <Button onClick={() => setEditingPlacement({ id: '', student_name: '', course: '', company_name: '', designation: '', package_lpa: 0, year: new Date().getFullYear(), is_featured: false })}>
                  <Plus className="h-4 w-4 mr-2" /> Add Placement
                </Button>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Student</TableHead>
                      <TableHead>Course</TableHead>
                      <TableHead>Company</TableHead>
                      <TableHead>Package</TableHead>
                      <TableHead>Year</TableHead>
                      <TableHead>Featured</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {placements.map((record) => (
                      <TableRow key={record.id}>
                        <TableCell className="font-medium">{record.student_name}</TableCell>
                        <TableCell>{record.course}</TableCell>
                        <TableCell>{record.company_name}</TableCell>
                        <TableCell>₹{record.package_lpa} LPA</TableCell>
                        <TableCell>{record.year}</TableCell>
                        <TableCell>
                          <Badge variant={record.is_featured ? "default" : "secondary"}>
                            {record.is_featured ? "Yes" : "No"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="ghost" size="sm" onClick={() => setEditingPlacement(record)}>
                              <Edit2 className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => deletePlacement(record.id)}>
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* MEIA Tab */}
          <TabsContent value="meia" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>MEIA AI Assistant Settings</CardTitle>
                <CardDescription>Configure the AI chatbot behavior</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>System Prompt</Label>
                  <Textarea 
                    rows={6}
                    defaultValue="You are Meia, a friendly and helpful AI cat assistant for IBCI Fly Wings educational platform."
                    className="font-mono text-sm"
                  />
                </div>
                <Button><Save className="h-4 w-4 mr-2" /> Save Settings</Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid md:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Chats</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{analytics.totalChats}</div>
                  <p className="text-xs text-green-600">+12% from last month</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Active Users</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{analytics.activeUsers}</div>
                  <p className="text-xs text-green-600">+8% from yesterday</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Avg Response Time</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{analytics.avgResponseTime}</div>
                  <p className="text-xs text-green-600">-0.5s improvement</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Satisfaction Rate</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{analytics.satisfactionRate}</div>
                  <p className="text-xs text-green-600">+2% this week</p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Usage Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] flex items-end justify-between gap-2">
                  {[65, 85, 72, 95, 88, 78, 92].map((height, i) => (
                    <div key={i} className="flex-1 flex flex-col items-center gap-2">
                      <div 
                        className="w-full bg-primary rounded-t-lg transition-all hover:bg-primary/80"
                        style={{ height: `${height}%` }}
                      />
                      <span className="text-xs text-muted-foreground">
                        {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i]}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Edit Content Dialog */}
        <Dialog open={!!editingContent} onOpenChange={() => setEditingContent(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Edit Content: {editingContent?.section_key}</DialogTitle>
            </DialogHeader>
            {editingContent && (
              <div className="space-y-4">
                <div>
                  <Label>Title</Label>
                  <Input 
                    value={editingContent.title || ''} 
                    onChange={(e) => setEditingContent({...editingContent, title: e.target.value})}
                  />
                </div>
                <div>
                  <Label>Subtitle</Label>
                  <Input 
                    value={editingContent.subtitle || ''} 
                    onChange={(e) => setEditingContent({...editingContent, subtitle: e.target.value})}
                  />
                </div>
                <div>
                  <Label>Content</Label>
                  <Textarea 
                    rows={4}
                    value={editingContent.content || ''} 
                    onChange={(e) => setEditingContent({...editingContent, content: e.target.value})}
                  />
                </div>
                <div>
                  <Label>Image URL</Label>
                  <Input 
                    value={editingContent.image_url || ''} 
                    onChange={(e) => setEditingContent({...editingContent, image_url: e.target.value})}
                  />
                </div>
                <Button onClick={() => saveContent(editingContent)} className="w-full">
                  <Save className="h-4 w-4 mr-2" /> Save Changes
                </Button>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Edit Faculty Dialog */}
        <Dialog open={!!editingFaculty} onOpenChange={() => setEditingFaculty(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{editingFaculty?.id ? 'Edit' : 'Add'} Faculty Member</DialogTitle>
            </DialogHeader>
            {editingFaculty && (
              <div className="space-y-4 max-h-[60vh] overflow-y-auto">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Name</Label>
                    <Input 
                      value={editingFaculty.name || ''} 
                      onChange={(e) => setEditingFaculty({...editingFaculty, name: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label>Designation</Label>
                    <Input 
                      value={editingFaculty.designation || ''} 
                      onChange={(e) => setEditingFaculty({...editingFaculty, designation: e.target.value})}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Department</Label>
                    <Input 
                      value={editingFaculty.department || ''} 
                      onChange={(e) => setEditingFaculty({...editingFaculty, department: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label>Experience (Years)</Label>
                    <Input 
                      type="number"
                      value={editingFaculty.experience_years || 0} 
                      onChange={(e) => setEditingFaculty({...editingFaculty, experience_years: parseInt(e.target.value)})}
                    />
                  </div>
                </div>
                <div>
                  <Label>Qualifications</Label>
                  <Input 
                    value={editingFaculty.qualifications || ''} 
                    onChange={(e) => setEditingFaculty({...editingFaculty, qualifications: e.target.value})}
                  />
                </div>
                <div>
                  <Label>Bio</Label>
                  <Textarea 
                    rows={3}
                    value={editingFaculty.bio || ''} 
                    onChange={(e) => setEditingFaculty({...editingFaculty, bio: e.target.value})}
                  />
                </div>
                <div>
                  <Label>Image URL</Label>
                  <Input 
                    value={editingFaculty.image_url || ''} 
                    onChange={(e) => setEditingFaculty({...editingFaculty, image_url: e.target.value})}
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Switch 
                    checked={editingFaculty.is_active} 
                    onCheckedChange={(checked) => setEditingFaculty({...editingFaculty, is_active: checked})}
                  />
                  <Label>Active</Label>
                </div>
                <Button onClick={() => saveFaculty(editingFaculty)} className="w-full">
                  <Save className="h-4 w-4 mr-2" /> Save
                </Button>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Edit Placement Dialog */}
        <Dialog open={!!editingPlacement} onOpenChange={() => setEditingPlacement(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{editingPlacement?.id ? 'Edit' : 'Add'} Placement Record</DialogTitle>
            </DialogHeader>
            {editingPlacement && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Student Name</Label>
                    <Input 
                      value={editingPlacement.student_name || ''} 
                      onChange={(e) => setEditingPlacement({...editingPlacement, student_name: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label>Course</Label>
                    <Input 
                      value={editingPlacement.course || ''} 
                      onChange={(e) => setEditingPlacement({...editingPlacement, course: e.target.value})}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Company Name</Label>
                    <Input 
                      value={editingPlacement.company_name || ''} 
                      onChange={(e) => setEditingPlacement({...editingPlacement, company_name: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label>Designation</Label>
                    <Input 
                      value={editingPlacement.designation || ''} 
                      onChange={(e) => setEditingPlacement({...editingPlacement, designation: e.target.value})}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Package (LPA)</Label>
                    <Input 
                      type="number"
                      step="0.1"
                      value={editingPlacement.package_lpa || 0} 
                      onChange={(e) => setEditingPlacement({...editingPlacement, package_lpa: parseFloat(e.target.value)})}
                    />
                  </div>
                  <div>
                    <Label>Year</Label>
                    <Input 
                      type="number"
                      value={editingPlacement.year || new Date().getFullYear()} 
                      onChange={(e) => setEditingPlacement({...editingPlacement, year: parseInt(e.target.value)})}
                    />
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Switch 
                    checked={editingPlacement.is_featured} 
                    onCheckedChange={(checked) => setEditingPlacement({...editingPlacement, is_featured: checked})}
                  />
                  <Label>Featured</Label>
                </div>
                <Button onClick={() => savePlacement(editingPlacement)} className="w-full">
                  <Save className="h-4 w-4 mr-2" /> Save
                </Button>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}