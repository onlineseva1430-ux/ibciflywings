import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Mail, Phone, Lock } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function Signup() {
  const [emailData, setEmailData] = useState({ email: "", password: "", confirmPassword: "" });
  const [phoneData, setPhoneData] = useState({ phone: "", otp: "", captcha: "" });
  const [captchaValue] = useState(Math.floor(1000 + Math.random() * 9000).toString());
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleEmailSignup = (e: React.FormEvent) => {
    e.preventDefault();
    if (emailData.password !== emailData.confirmPassword) {
      toast({
        title: "Error",
        description: "Passwords do not match!",
        variant: "destructive"
      });
      return;
    }
    toast({
      title: "Success!",
      description: "Account created successfully. Redirecting to home...",
    });
    setTimeout(() => {
      navigate('/');
    }, 1500);
  };

  const handlePhoneSignup = (e: React.FormEvent) => {
    e.preventDefault();
    if (phoneData.captcha !== captchaValue) {
      toast({
        title: "Error",
        description: "Invalid captcha. Please try again.",
        variant: "destructive"
      });
      return;
    }
    toast({
      title: "Success!",
      description: "OTP sent successfully. Redirecting to home...",
    });
    setTimeout(() => {
      navigate('/');
    }, 1500);
  };

  const handleGoogleSignup = () => {
    toast({
      title: "Google Sign Up",
      description: "Redirecting to Google authentication...",
    });
    setTimeout(() => {
      navigate('/');
    }, 1500);
  };

  return (
    <div className="min-h-screen flex items-center justify-center py-12 px-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold text-primary">Sign Up</CardTitle>
          <CardDescription>Create your account to get started with IBCI Fly Wings</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="google" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="google">Google</TabsTrigger>
              <TabsTrigger value="email">Email</TabsTrigger>
              <TabsTrigger value="phone">Phone</TabsTrigger>
            </TabsList>

            {/* Google Sign Up */}
            <TabsContent value="google" className="space-y-4">
              <Button 
                onClick={handleGoogleSignup} 
                className="w-full" 
                variant="outline"
                size="lg"
              >
                <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
                  <path
                    fill="currentColor"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="currentColor"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="currentColor"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  />
                  <path
                    fill="currentColor"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  />
                </svg>
                Continue with Google
              </Button>
              <p className="text-xs text-center text-muted-foreground">
                By signing up with Google, you agree to our Terms of Service and Privacy Policy.
              </p>
            </TabsContent>

            {/* Email Sign Up */}
            <TabsContent value="email">
              <form onSubmit={handleEmailSignup} className="space-y-4">
                <div>
                  <Label htmlFor="email" className="flex items-center gap-2">
                    <Mail className="h-4 w-4" />
                    Email Address
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your.email@example.com"
                    value={emailData.email}
                    onChange={(e) => setEmailData({ ...emailData, email: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="password" className="flex items-center gap-2">
                    <Lock className="h-4 w-4" />
                    Password
                  </Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Create a strong password"
                    value={emailData.password}
                    onChange={(e) => setEmailData({ ...emailData, password: e.target.value })}
                    required
                    minLength={8}
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Minimum 8 characters
                  </p>
                </div>

                <div>
                  <Label htmlFor="confirmPassword">Confirm Password</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    placeholder="Re-enter your password"
                    value={emailData.confirmPassword}
                    onChange={(e) => setEmailData({ ...emailData, confirmPassword: e.target.value })}
                    required
                  />
                </div>

                <Button 
                  type="submit" 
                  className="w-full relative overflow-hidden group transition-all duration-300 hover:scale-105 hover:shadow-xl"
                >
                  <span className="relative z-10">Create Account</span>
                  <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-0 group-hover:opacity-100 group-hover:animate-shimmer"></span>
                </Button>
              </form>
            </TabsContent>

            {/* Phone Sign Up */}
            <TabsContent value="phone">
              <form onSubmit={handlePhoneSignup} className="space-y-4">
                <div>
                  <Label htmlFor="phone" className="flex items-center gap-2">
                    <Phone className="h-4 w-4" />
                    Phone Number
                  </Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="+91 XXXXXXXXXX"
                    value={phoneData.phone}
                    onChange={(e) => setPhoneData({ ...phoneData, phone: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="captcha">Enter Captcha</Label>
                  <div className="flex gap-2 items-center mb-2">
                    <div className="bg-muted px-4 py-2 rounded font-mono text-lg tracking-wider">
                      {captchaValue}
                    </div>
                  </div>
                  <Input
                    id="captcha"
                    type="text"
                    placeholder="Enter the code above"
                    value={phoneData.captcha}
                    onChange={(e) => setPhoneData({ ...phoneData, captcha: e.target.value })}
                    required
                  />
                </div>

                <Button 
                  type="submit" 
                  className="w-full relative overflow-hidden group transition-all duration-300 hover:scale-105 hover:shadow-xl"
                >
                  <span className="relative z-10">Send OTP</span>
                  <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-0 group-hover:opacity-100 group-hover:animate-shimmer"></span>
                </Button>

                {phoneData.otp && (
                  <div>
                    <Label htmlFor="otp">Enter OTP</Label>
                    <Input
                      id="otp"
                      type="text"
                      placeholder="Enter 6-digit OTP"
                      maxLength={6}
                      value={phoneData.otp}
                      onChange={(e) => setPhoneData({ ...phoneData, otp: e.target.value })}
                    />
                  </div>
                )}
              </form>
            </TabsContent>
          </Tabs>

          <div className="mt-6 text-center">
            <p className="text-sm text-muted-foreground">
              Already have an account?{" "}
              <a href="/login" className="text-primary hover:underline font-semibold">
                Sign In
              </a>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
