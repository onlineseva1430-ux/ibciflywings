import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight, Star, Users, BookOpen, Award, Target, Eye, Download, Play, CheckCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { PlacementForm } from "@/components/PlacementForm";
import { CourseCarousel } from "@/components/CourseCarousel";
import { IbciPlaySection } from "@/components/IbciPlaySection";
import { CharityProgramSection } from "@/components/CharityProgramSection";
import { MeiaCat } from "@/components/MeiaCat";
import { useMeiaCat } from "@/hooks/useMeiaCat";
import { MeiaIntroSection } from "@/components/MeiaIntroSection";

export const Home = () => {
  const { showMeia, currentMessage, triggerMeia, hideMeia } = useMeiaCat();

  const testimonials = [
    {
      name: "Priya Sharma",
      course: "CA Final",
      message: "IBCI Fly Wings transformed my approach to studying. The faculty is exceptional!",
      rating: 5
    },
    {
      name: "Rahul Kumar",
      course: "CMA",
      message: "The live classes and recorded lectures helped me balance work and studies perfectly.",
      rating: 5
    },
    {
      name: "Anita Patel",
      course: "ACCA",
      message: "Best investment in my career. The support system is incredible.",
      rating: 5
    }
  ];

  const features = [
    "Expert Faculty & Structured Courses",
    "Live Classes & Recorded Sessions",
    "Personalised Study Plans",
    "Regular Tests & Performance Analysis",
    "Motivational Support & Guidance",
    "Affordable Excellence"
  ];

  return (
    <div className="min-h-screen">
      {/* Meia Cat Assistant */}
      {showMeia && <MeiaCat message={currentMessage} onClose={hideMeia} />}

      {/* Hero Section - Two Column Layout */}
      <section className="relative min-h-[85vh] flex items-center bg-gradient-to-br from-background via-secondary/30 to-background overflow-hidden">
        {/* Background decorative shapes */}
        <div className="absolute top-20 right-10 w-72 h-72 bg-accent/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-10 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 w-full">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left Side - Content */}
            <div className="space-y-8">
              <div className="space-y-6">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold text-foreground leading-tight animate-fade-in-up">
                  Your Gateway to{" "}
                  <span className="text-primary">Professional Excellence</span>
                </h1>
                <p className="text-lg md:text-xl text-muted-foreground leading-relaxed animate-fade-in-up [animation-delay:200ms]">
                  Master <span className="font-semibold text-foreground">CA, CMA, ACCA, CS, MBA & Degree</span> Programs with India's leading faculty. Learn anytime, anywhere.
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4 animate-fade-in-up [animation-delay:400ms]">
                <Button 
                  size="lg" 
                  variant="outline"
                  asChild 
                  className="text-lg px-8 py-6 border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground rounded-full transition-all duration-300 hover:shadow-lg"
                >
                  <Link to="/courses">
                    Explore Courses <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button 
                  size="lg" 
                  asChild
                  className="text-lg px-8 py-6 bg-accent hover:bg-accent/90 text-accent-foreground rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
                >
                  <a 
                    href="https://preview--fly-wings-campus-connect.lovable.app/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                  >
                    <Download className="mr-2 h-5 w-5" />
                    Download App
                  </a>
                </Button>
              </div>

              {/* Quick stats */}
              <div className="flex flex-wrap gap-8 pt-4 animate-fade-in-up [animation-delay:600ms]">
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary font-heading">5000+</div>
                  <div className="text-sm text-muted-foreground">Students</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary font-heading">95%</div>
                  <div className="text-sm text-muted-foreground">Success Rate</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary font-heading">4.9/5</div>
                  <div className="text-sm text-muted-foreground">Rating</div>
                </div>
              </div>
            </div>

            {/* Right Side - Image */}
            <div className="relative hidden lg:block animate-fade-in-up [animation-delay:300ms]">
              <div className="relative">
                {/* Decorative background shapes */}
                <div className="absolute -top-4 -right-4 w-full h-full bg-accent/20 rounded-3xl" />
                <div className="absolute -bottom-4 -left-4 w-full h-full bg-primary/10 rounded-3xl" />
                
                {/* Main image container */}
                <div className="relative bg-gradient-to-br from-primary/20 to-accent/20 rounded-3xl p-8 backdrop-blur-sm">
                  <img 
                    src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=600&h=700&fit=crop"
                    alt="Professional student studying"
                    className="w-full h-[500px] object-cover rounded-2xl shadow-2xl"
                  />
                </div>

                {/* Floating badge */}
                <div className="absolute -bottom-6 -left-6 bg-background rounded-xl shadow-xl p-4 border border-border">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center">
                      <Award className="h-6 w-6 text-accent" />
                    </div>
                    <div>
                      <div className="font-semibold text-foreground">Top Rated</div>
                      <div className="text-sm text-muted-foreground">Institute in India</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Promo Video Section */}
      <section id="promo-video" className="py-20 bg-secondary/30">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4 text-foreground">Discover IBCI Fly Wings</h2>
            <p className="text-xl text-muted-foreground">
              Watch our story and see how we're transforming professional education
            </p>
          </div>
          <div className="relative aspect-video rounded-2xl overflow-hidden shadow-2xl border border-border">
            <video 
              controls 
              controlsList="nodownload noplaybackrate"
              disablePictureInPicture
              disableRemotePlayback
              className="w-full h-full"
              poster="https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=1200&h=675&fit=crop"
              onContextMenu={(e) => e.preventDefault()}
            >
              <source src="/videos/ibci-promo.mp4" type="video/mp4" />
              Your browser does not support the video tag.
            </video>
          </div>
        </div>
      </section>

      {/* About Us Section */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4 text-foreground">About IBCI Fly Wings</h2>
            <p className="text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed mb-8">
              IBCI Fly Wings is a premier online learning platform dedicated to transforming the way you prepare for your dream professional qualifications.
            </p>
            
            {/* Motivational Quote */}
            <div className="bg-gradient-to-r from-primary/10 to-accent/10 p-8 rounded-2xl mb-12 border border-border">
              <blockquote className="text-2xl md:text-3xl font-heading font-bold text-primary text-center italic">
                "Your wings already exist. All you have to do is fly."
              </blockquote>
              <p className="text-muted-foreground text-center mt-2">- IBCI FLY WINGS</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            <Card className="border-l-4 border-l-primary shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                    <Target className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-2xl font-heading">Our Mission</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">
                  To empower students with knowledge, confidence, and skills to crack any professional exam and become leaders in their chosen field.
                </p>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-accent shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center">
                    <Eye className="h-6 w-6 text-accent" />
                  </div>
                  <CardTitle className="text-2xl font-heading">Our Vision</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">
                  To be the leading institute for professional education, recognized globally for our innovative teaching methods and student success rates.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Why Choose Us - Feature List */}
          <div className="mb-12">
            <h3 className="text-2xl font-heading font-bold text-center mb-8 text-foreground">Why Choose IBCI Fly Wings?</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center gap-3 p-4 bg-secondary/50 rounded-xl hover:bg-secondary transition-colors">
                  <CheckCircle className="h-5 w-5 text-accent flex-shrink-0" />
                  <span className="text-foreground font-medium">{feature}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <PlacementForm />
            <Button 
              size="lg" 
              className="bg-accent hover:bg-accent/90 text-accent-foreground rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
              asChild
            >
              <a 
                href="https://preview--fly-wings-campus-connect.lovable.app/" 
                target="_blank" 
                rel="noopener noreferrer"
              >
                <Download className="mr-2 h-5 w-5" />
                Download App Now
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* Charity Program Section */}
      <div onClick={() => triggerMeia("charity")}>
        <CharityProgramSection />
      </div>

      {/* Meia Introduction Section */}
      <MeiaIntroSection />

      {/* IBCI Play Section */}
      <div onClick={() => triggerMeia("ibciPlay")}>
        <IbciPlaySection />
      </div>

      {/* Course Carousel Section */}
      <section className="py-20 bg-secondary/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4 text-foreground">Explore Our Courses</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Professional programs designed to transform your career
            </p>
          </div>

          <CourseCarousel />

          <div className="text-center mt-12">
            <Button 
              size="lg" 
              asChild 
              className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full shadow-lg hover:shadow-xl transition-all duration-300 px-8"
            >
              <Link to="/courses">
                View All Courses 
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-gradient-to-br from-primary via-primary to-accent text-primary-foreground relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi02LTIuNjg2LTYtNiAyLjY4Ni02IDYtNnptMCAxMmMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi02LTIuNjg2LTYtNiAyLjY4Ni02IDYtNnpNMTggMThjMy4zMTQgMCA2IDIuNjg2IDYgNnMtMi42ODYgNi02IDYtNi0yLjY4Ni02LTYgMi42ODYtNiA2LTZ6bTAgMTJjMy4zMTQgMCA2IDIuNjg2IDYgNnMtMi42ODYgNi02IDYtNi0yLjY4Ni02LTYgMi42ODYtNiA2LTZ6IiBmaWxsPSIjZmZmIiBvcGFjaXR5PSIuMDUiLz48L2c+PC9zdmc+')] opacity-20"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 text-center">
            <div className="group">
              <Users className="h-12 w-12 mx-auto mb-4 opacity-80 group-hover:scale-110 transition-transform" />
              <div className="text-4xl font-heading font-bold mb-2">5000+</div>
              <div className="text-primary-foreground/80">Students Enrolled</div>
            </div>
            <div className="group">
              <BookOpen className="h-12 w-12 mx-auto mb-4 opacity-80 group-hover:scale-110 transition-transform" />
              <div className="text-4xl font-heading font-bold mb-2">15+</div>
              <div className="text-primary-foreground/80">Expert Faculty</div>
            </div>
            <div className="group">
              <Award className="h-12 w-12 mx-auto mb-4 opacity-80 group-hover:scale-110 transition-transform" />
              <div className="text-4xl font-heading font-bold mb-2">95%</div>
              <div className="text-primary-foreground/80">Success Rate</div>
            </div>
            <div className="group">
              <Star className="h-12 w-12 mx-auto mb-4 opacity-80 group-hover:scale-110 transition-transform" />
              <div className="text-4xl font-heading font-bold mb-2">4.9/5</div>
              <div className="text-primary-foreground/80">Student Rating</div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4 text-foreground">Student Success Stories</h2>
            <p className="text-xl text-muted-foreground">
              Hear from our successful students who have achieved their dreams
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="shadow-lg hover:shadow-xl transition-shadow duration-300 border-t-4 border-t-accent">
                <CardHeader>
                  <div className="flex items-center gap-1 mb-2">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-accent text-accent" />
                    ))}
                  </div>
                  <CardTitle className="text-lg font-heading">{testimonial.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">{testimonial.course}</p>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground italic">"{testimonial.message}"</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary to-accent text-primary-foreground">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4">
            Ready to Start Your Journey?
          </h2>
          <p className="text-xl mb-8 text-primary-foreground/90">
            Join thousands of successful students who chose IBCI Fly Wings
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              variant="secondary"
              asChild
              className="text-lg px-8 py-6 rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <Link to="/courses">
                Browse Courses <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button 
              size="lg" 
              asChild
              className="text-lg px-8 py-6 bg-primary-foreground text-primary hover:bg-primary-foreground/90 rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <Link to="/signup">
                Get Started Today
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};
