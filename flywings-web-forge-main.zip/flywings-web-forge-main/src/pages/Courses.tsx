import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { BookOpen, GraduationCap, Award, Star } from "lucide-react";
import { ReadableSection } from "@/components/ReadableSection";
import { useMeia } from "@/contexts/MeiaContext";
import { useEffect } from "react";

const courses = [
  {
    id: "ca",
    title: "CA (Chartered Accountancy)",
    description: "Become a Chartered Accountant with comprehensive training in accounting, taxation, and auditing.",
    details: "Our CA course covers all three levels - Foundation, Intermediate, and Final with expert faculty guidance. Includes regular mock tests, doubt clearing sessions, and comprehensive study material.",
    duration: "3-5 years",
    reviews: [
      { name: "Priya Sharma", rating: 5, text: "Excellent faculty and study material. Cleared CA Final in first attempt!" },
      { name: "Rahul Kumar", rating: 5, text: "The coaching quality is outstanding. Highly recommend IBCI Fly Wings." }
    ]
  },
  {
    id: "cma",
    title: "CMA (Cost Management Accountancy)",
    description: "Master cost accounting and management with our structured CMA program.",
    details: "Foundation, Intermediate, and Final levels covered with focus on cost accounting, financial management, and strategic management. Regular assessments and personalized guidance.",
    duration: "2-4 years",
    reviews: [
      { name: "Anjali Verma", rating: 5, text: "Best institute for CMA. Teachers are very supportive and knowledgeable." }
    ]
  },
  {
    id: "cma-usa",
    title: "CMA USA",
    description: "Globally recognized CMA certification from IMA, USA.",
    details: "Comprehensive coverage of Part 1 (Financial Planning) and Part 2 (Strategic Financial Management). Internationally recognized certification with global career opportunities.",
    duration: "1-2 years",
    reviews: [
      { name: "Vikram Singh", rating: 5, text: "Cleared both parts in first attempt. Great international exposure." }
    ]
  },
  {
    id: "acca",
    title: "ACCA",
    description: "Association of Chartered Certified Accountants - Global accounting qualification.",
    details: "Complete ACCA syllabus covered across all levels - Applied Knowledge, Applied Skills, and Strategic Professional. Regular practice sessions and exam-focused training.",
    duration: "2-3 years",
    reviews: [
      { name: "Neha Patel", rating: 5, text: "IBCI helped me achieve my dream of becoming ACCA certified. Excellent teaching!" }
    ]
  },
  {
    id: "degree",
    title: "Degree Programs (B.Com, BBA)",
    description: "Professional degree programs with commerce and business specializations.",
    details: "Complete degree syllabus with additional skill development courses. Focus on practical knowledge and placement assistance.",
    duration: "3 years",
    reviews: [
      { name: "Amit Joshi", rating: 4, text: "Good foundation for commerce students. Helpful faculty." }
    ]
  },
  {
    id: "mba",
    title: "MBA",
    description: "Master of Business Administration with specialization options.",
    details: "MBA preparation with focus on entrance exams (CAT, XAT, GMAT) and comprehensive business management subjects. Industry-oriented curriculum.",
    duration: "2 years",
    reviews: [
      { name: "Sneha Reddy", rating: 5, text: "Great MBA preparation. Got admission in top B-school!" }
    ]
  },
  {
    id: "cpa",
    title: "CPA (Certified Public Accountant)",
    description: "US-based professional accounting certification.",
    details: "Complete CPA exam preparation covering AUD, BEC, FAR, and REG sections. Expert guidance from internationally certified faculty.",
    duration: "1-2 years",
    reviews: [
      { name: "Karan Malhotra", rating: 5, text: "Best CPA coaching in India. Cleared all sections in 18 months!" }
    ]
  },
  {
    id: "cs",
    title: "CS (Company Secretary)",
    description: "Company Secretary course for corporate governance professionals.",
    details: "Complete CS syllabus - Executive and Professional levels with focus on corporate laws, secretarial practice, and governance.",
    duration: "2-3 years",
    reviews: [
      { name: "Pooja Agarwal", rating: 5, text: "Excellent course structure. Faculty is very experienced." }
    ]
  }
];

export default function Courses() {
  const [selectedCourse, setSelectedCourse] = useState<typeof courses[0] | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    course: "",
    qualification: "",
    message: ""
  });
  const { toast } = useToast();
  const { readContent } = useMeia();

  useEffect(() => {
    const timer = setTimeout(() => {
      readContent("Courses page: Transform your career with India's best professional courses including CA, CS, ACCA, CMA, MBA, and Degree programs. We provide expert faculty, comprehensive study material, and proven results.");
    }, 500);
    return () => clearTimeout(timer);
  }, [readContent]);

  const handleAdmissionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Application Submitted Successfully!",
      description: "Our team will contact you within 24 hours. Thank you for choosing IBCI Fly Wings!",
    });
    setFormData({
      name: "",
      email: "",
      phone: "",
      course: "",
      qualification: "",
      message: ""
    });
  };

  return (
    <div className="min-h-screen py-16 px-4">
      <div className="max-w-7xl mx-auto">
        <ReadableSection 
          content="Our Courses: Transform your career with India's best professional courses. Expert faculty, comprehensive study material, and proven results."
          sectionName="Courses Header"
        >
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">Our Courses</h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Transform your career with India's best professional courses. Expert faculty, comprehensive study material, and proven results.
            </p>
          </div>
        </ReadableSection>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {courses.map((course) => (
            <Card key={course.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <BookOpen className="h-8 w-8 text-primary" />
                  <span className="text-sm text-muted-foreground">{course.duration}</span>
                </div>
                <CardTitle className="text-xl">{course.title}</CardTitle>
                <CardDescription>{course.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button 
                      className="w-full"
                      onClick={() => setSelectedCourse(course)}
                    >
                      Learn More
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle className="text-2xl">{course.title}</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-6">
                      <div>
                        <h3 className="font-semibold text-lg mb-2 flex items-center gap-2">
                          <GraduationCap className="h-5 w-5 text-primary" />
                          Course Details
                        </h3>
                        <p className="text-muted-foreground">{course.details}</p>
                        <p className="mt-2"><strong>Duration:</strong> {course.duration}</p>
                      </div>
                      
                      <div>
                        <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                          <Award className="h-5 w-5 text-primary" />
                          Student Reviews
                        </h3>
                        <div className="space-y-3">
                          {course.reviews.map((review, idx) => (
                            <div key={idx} className="bg-muted p-4 rounded-lg">
                              <div className="flex items-center gap-2 mb-2">
                                <span className="font-semibold">{review.name}</span>
                                <div className="flex">
                                  {[...Array(review.rating)].map((_, i) => (
                                    <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                                  ))}
                                </div>
                              </div>
                              <p className="text-sm text-muted-foreground">{review.text}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Admission Form */}
        <div className="bg-card p-8 rounded-lg shadow-lg max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-primary mb-6 text-center">Apply for Admission</h2>
          <form onSubmit={handleAdmissionSubmit} className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Full Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="phone">Phone Number *</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="course">Select Course *</Label>
                <Select value={formData.course} onValueChange={(value) => setFormData({ ...formData, course: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a course" />
                  </SelectTrigger>
                  <SelectContent>
                    {courses.map((course) => (
                      <SelectItem key={course.id} value={course.id}>
                        {course.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="qualification">Current Qualification *</Label>
              <Input
                id="qualification"
                value={formData.qualification}
                onChange={(e) => setFormData({ ...formData, qualification: e.target.value })}
                placeholder="e.g., 12th Pass, Graduate, etc."
                required
              />
            </div>

            <div>
              <Label htmlFor="message">Additional Information</Label>
              <Textarea
                id="message"
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                placeholder="Any questions or special requirements?"
                rows={4}
              />
            </div>

            <Button type="submit" className="w-full" size="lg">
              Submit Application
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
