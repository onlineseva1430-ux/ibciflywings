import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Mail, Linkedin, GraduationCap, Award, Users } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import facultyTeam from "@/assets/faculty-team.jpg";

interface FacultyMember {
  id: string;
  name: string;
  designation: string;
  department: string;
  qualifications: string;
  experience_years: number;
  bio: string;
  image_url: string;
  email: string;
  linkedin_url: string;
  specializations: string[];
}

export default function Faculty() {
  const [faculty, setFaculty] = useState<FacultyMember[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFaculty = async () => {
      const { data, error } = await supabase
        .from("faculty_members")
        .select("*")
        .eq("is_active", true)
        .order("display_order", { ascending: true });
      
      if (data) {
        setFaculty(data);
      }
      setLoading(false);
    };
    fetchFaculty();
  }, []);

  const stats = [
    { icon: Users, value: "15+", label: "Expert Faculty" },
    { icon: GraduationCap, value: "50+", label: "Years Combined Experience" },
    { icon: Award, value: "5000+", label: "Students Taught" },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src={facultyTeam} 
            alt="Our Faculty Team" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-primary/95 via-primary/85 to-transparent"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Badge variant="secondary" className="mb-6 text-base px-6 py-2">
            Meet Our Experts
          </Badge>
          <h1 className="text-5xl md:text-6xl font-bold text-primary-foreground mb-6">
            World-Class Faculty
          </h1>
          <p className="text-xl md:text-2xl text-primary-foreground/90 max-w-3xl leading-relaxed">
            Learn from industry experts with decades of experience in professional education and real-world practice.
          </p>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-3 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <stat.icon className="h-10 w-10 mx-auto mb-3 text-primary" />
                <div className="text-3xl md:text-4xl font-bold text-primary">{stat.value}</div>
                <div className="text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Faculty Grid */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Distinguished Faculty</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Each member brings unique expertise and dedication to student success
            </p>
          </div>

          {loading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="animate-pulse">
                  <div className="h-64 bg-muted"></div>
                  <CardContent className="p-6">
                    <div className="h-6 bg-muted rounded mb-2"></div>
                    <div className="h-4 bg-muted rounded w-2/3"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {faculty.map((member) => (
                <Card key={member.id} className="overflow-hidden hover:shadow-xl transition-all group">
                  <div className="relative h-64 bg-gradient-to-br from-primary/10 to-accent/10 flex items-center justify-center">
                    {member.image_url ? (
                      <img 
                        src={member.image_url} 
                        alt={member.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-32 h-32 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                        <span className="text-4xl font-bold text-primary-foreground">
                          {member.name.split(' ').map(n => n[0]).join('')}
                        </span>
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                  </div>
                  
                  <CardHeader className="pb-2">
                    <CardTitle className="text-xl">{member.name}</CardTitle>
                    <CardDescription className="text-primary font-medium">
                      {member.designation}
                    </CardDescription>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    {member.department && (
                      <p className="text-sm text-muted-foreground">
                        Department: {member.department}
                      </p>
                    )}
                    
                    {member.qualifications && (
                      <p className="text-sm">
                        <span className="font-medium">Qualifications:</span> {member.qualifications}
                      </p>
                    )}
                    
                    {member.experience_years && (
                      <p className="text-sm text-muted-foreground">
                        {member.experience_years}+ years of experience
                      </p>
                    )}
                    
                    {member.bio && (
                      <p className="text-sm text-muted-foreground line-clamp-3">
                        {member.bio}
                      </p>
                    )}
                    
                    {member.specializations && member.specializations.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {member.specializations.map((spec, idx) => (
                          <Badge key={idx} variant="secondary" className="text-xs">
                            {spec}
                          </Badge>
                        ))}
                      </div>
                    )}
                    
                    <div className="flex gap-2 pt-2">
                      {member.email && (
                        <Button variant="outline" size="sm" asChild>
                          <a href={`mailto:${member.email}`}>
                            <Mail className="h-4 w-4" />
                          </a>
                        </Button>
                      )}
                      {member.linkedin_url && (
                        <Button variant="outline" size="sm" asChild>
                          <a href={member.linkedin_url} target="_blank" rel="noopener noreferrer">
                            <Linkedin className="h-4 w-4" />
                          </a>
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary to-accent text-primary-foreground">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Learn from the Best</h2>
          <p className="text-xl text-primary-foreground/90 mb-8">
            Our faculty members are not just teachers—they're mentors committed to your success.
          </p>
          <Button size="lg" variant="secondary" asChild>
            <a href="/courses">Explore Our Courses</a>
          </Button>
        </div>
      </section>
    </div>
  );
}