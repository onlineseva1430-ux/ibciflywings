import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Video, Clock, MapPin, Wifi, AlertCircle } from "lucide-react";
import { ReadableSection } from "@/components/ReadableSection";
import { useMeia } from "@/contexts/MeiaContext";
import { useEffect } from "react";

export default function LiveClasses() {
  const { readContent } = useMeia();

  useEffect(() => {
    // Auto-read page introduction when user lands on this page
    const timer = setTimeout(() => {
      readContent("Live Classes page: Interactive learning with expert faculty in both online and offline modes. We offer flexible timing and recorded sessions for revision.");
    }, 500);
    return () => clearTimeout(timer);
  }, [readContent]);

  return (
    <div className="min-h-screen py-16 px-4">
      <div className="max-w-5xl mx-auto">
        <ReadableSection 
          content="Live Classes: Interactive learning with expert faculty in both online and offline modes"
          sectionName="Live Classes Header"
        >
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">Live Classes</h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Interactive learning with expert faculty in both online and offline modes
            </p>
          </div>
        </ReadableSection>

        {/* Highlighted Alert */}
        <Alert className="mb-8 bg-accent text-accent-foreground border-accent">
          <AlertCircle className="h-5 w-5" />
          <AlertDescription className="text-base font-semibold">
            🎁 Special Benefit: After class validity expiry, get an extra 20 days to complete all recorded classes!
          </AlertDescription>
        </Alert>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {/* Online Classes */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-2xl">
                <Wifi className="h-8 w-8 text-primary" />
                Online Classes
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <Video className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold mb-1">Live Interactive Sessions</h3>
                  <p className="text-sm text-muted-foreground">
                    Attend classes from anywhere with real-time interaction with faculty. HD video quality with crystal clear audio.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold mb-1">Flexible Timing</h3>
                  <p className="text-sm text-muted-foreground">
                    Multiple batch timings available - morning, afternoon, and evening sessions to suit your schedule.
                  </p>
                </div>
              </div>

              <div className="bg-muted p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Features Include:</h4>
                <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                  <li>Live doubt clearing sessions</li>
                  <li>Screen sharing for better understanding</li>
                  <li>Digital whiteboard for explanations</li>
                  <li>Recorded sessions for revision</li>
                  <li>Chat support during classes</li>
                  <li>Attendance tracking</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Offline Classes */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-2xl">
                <MapPin className="h-8 w-8 text-primary" />
                Offline Classes
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <Video className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold mb-1">Face-to-Face Learning</h3>
                  <p className="text-sm text-muted-foreground">
                    Traditional classroom experience with direct interaction with faculty and fellow students.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold mb-1">Structured Schedule</h3>
                  <p className="text-sm text-muted-foreground">
                    Regular classes at our state-of-the-art facilities with modern teaching aids and comfortable seating.
                  </p>
                </div>
              </div>

              <div className="bg-muted p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Features Include:</h4>
                <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                  <li>Air-conditioned smart classrooms</li>
                  <li>Digital projectors and boards</li>
                  <li>Printed study materials</li>
                  <li>Library and study areas</li>
                  <li>Personal mentorship</li>
                  <li>Peer learning environment</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* How Classes are Conducted */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-2xl">How Our Classes Are Conducted</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="font-semibold text-lg mb-3">Class Structure</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-muted p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">📚 Topic-wise Coverage</h4>
                  <p className="text-sm text-muted-foreground">
                    Systematic syllabus coverage with comprehensive notes and examples
                  </p>
                </div>
                <div className="bg-muted p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">✍️ Regular Practice</h4>
                  <p className="text-sm text-muted-foreground">
                    Topic-wise tests and assignments to reinforce learning
                  </p>
                </div>
                <div className="bg-muted p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">💡 Doubt Sessions</h4>
                  <p className="text-sm text-muted-foreground">
                    Dedicated doubt clearing sessions after each topic
                  </p>
                </div>
                <div className="bg-muted p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">📊 Performance Analysis</h4>
                  <p className="text-sm text-muted-foreground">
                    Regular assessments with detailed performance reports
                  </p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold text-lg mb-3">Class Recordings & Validity</h3>
              <div className="space-y-3">
                <p className="text-muted-foreground">
                  All live classes are recorded and made available to students for revision purposes. You can access these recordings anytime during your course validity period.
                </p>
                <Alert className="bg-primary/10 border-primary">
                  <AlertCircle className="h-5 w-5 text-primary" />
                  <AlertDescription>
                    <strong>Extended Access:</strong> Even after your class validity expires, you get an additional 20 days to complete watching all recorded sessions. This ensures you don't miss out on any content!
                  </AlertDescription>
                </Alert>
              </div>
            </div>

            <div>
              <h3 className="font-semibold text-lg mb-3">Study Material & Resources</h3>
              <ul className="text-muted-foreground space-y-2 list-disc list-inside">
                <li>Comprehensive study notes for each topic</li>
                <li>Question banks with previous year papers</li>
                <li>Mock test series aligned with exam patterns</li>
                <li>Revision modules and summary sheets</li>
                <li>Additional reference materials and articles</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Call to Action */}
        <div className="text-center bg-primary text-primary-foreground p-8 rounded-lg">
          <h2 className="text-2xl font-bold mb-3">Ready to Start Your Journey?</h2>
          <p className="mb-6">Join thousands of successful students who chose IBCI Fly Wings</p>
          <div className="flex gap-4 justify-center flex-wrap">
            <a 
              href="/courses" 
              className="bg-secondary text-secondary-foreground px-6 py-3 rounded-md font-semibold hover:opacity-90 transition-opacity"
            >
              View All Courses
            </a>
            <a 
              href="/contact" 
              className="bg-accent text-accent-foreground px-6 py-3 rounded-md font-semibold hover:opacity-90 transition-opacity"
            >
              Contact Us
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
