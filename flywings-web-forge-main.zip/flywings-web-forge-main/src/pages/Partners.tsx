import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Helmet } from "react-helmet-async";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ExternalLink, Music, GraduationCap, Heart, Users } from "lucide-react";
import vibraLogo from "@/assets/vibra-logo.png";
import ibciLogo from "@/assets/ibci-logo.png";

interface PartnerPageData {
  title: string;
  subtitle: string | null;
  content: string | null;
}

export default function Partners() {
  const [page, setPage] = useState<PartnerPageData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPage = async () => {
      const { data } = await supabase
        .from("cms_pages")
        .select("title, subtitle, content")
        .eq("slug", "partners")
        .eq("is_published", true)
        .maybeSingle();

      if (data) setPage(data);
      setLoading(false);
    };

    fetchPage();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Partners - Vibra × IBCI Fly Wings</title>
        <meta name="description" content="Discover the powerful partnership between Vibra Music and IBCI Fly Wings Institute." />
      </Helmet>
      
      <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-background">
        {/* Hero Section */}
        <section className="relative py-20 px-4 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-accent/5" />
          <div className="max-w-6xl mx-auto text-center relative z-10">
            <div className="flex items-center justify-center gap-8 mb-8">
              <div className="w-24 h-24 md:w-32 md:h-32 rounded-2xl bg-black p-4 shadow-xl">
                <img src={vibraLogo} alt="Vibra Music" className="w-full h-full object-contain" />
              </div>
              <span className="text-4xl font-bold text-primary">×</span>
              <div className="w-24 h-24 md:w-32 md:h-32 rounded-2xl bg-white p-4 shadow-xl">
                <img src={ibciLogo} alt="IBCI Fly Wings" className="w-full h-full object-contain" />
              </div>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              {page?.title || "Our Partners"}
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              {page?.subtitle || "A powerful collaboration for artists and education"}
            </p>
          </div>
        </section>

        {/* Partners Cards */}
        <section className="py-16 px-4">
          <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-8">
            {/* Vibra Card */}
            <Card className="overflow-hidden border-2 border-primary/20 hover:border-primary/40 transition-colors">
              <div className="h-4 bg-gradient-to-r from-red-500 to-red-600" />
              <CardContent className="p-8">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 rounded-xl bg-black p-2">
                    <img src={vibraLogo} alt="Vibra Music" className="w-full h-full object-contain" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-foreground">Vibra Music</h2>
                    <p className="text-muted-foreground">Streaming Platform</p>
                  </div>
                </div>
                <p className="text-muted-foreground mb-6">
                  A platform for artists, creators, and music lovers to upload, share, and enjoy a modern streaming experience. Vibra empowers independent artists to reach their audience.
                </p>
                <div className="flex flex-wrap gap-3">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Music className="h-4 w-4 text-primary" />
                    <span>Music Streaming</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Users className="h-4 w-4 text-primary" />
                    <span>Artist Support</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* IBCI Card */}
            <Card className="overflow-hidden border-2 border-primary/20 hover:border-primary/40 transition-colors">
              <div className="h-4 bg-gradient-to-r from-primary to-primary/80" />
              <CardContent className="p-8">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 rounded-xl bg-white p-2">
                    <img src={ibciLogo} alt="IBCI Fly Wings" className="w-full h-full object-contain" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-foreground">IBCI Fly Wings</h2>
                    <p className="text-muted-foreground">Educational Institute</p>
                  </div>
                </div>
                <p className="text-muted-foreground mb-6">
                  An educational platform supporting Vibra's mission by providing talents, offering charity programs for underprivileged students, and supporting artistic growth.
                </p>
                <div className="flex flex-wrap gap-3">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <GraduationCap className="h-4 w-4 text-primary" />
                    <span>Education</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Heart className="h-4 w-4 text-primary" />
                    <span>Charity Programs</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Mission Section */}
        <section className="py-16 px-4 bg-muted/30">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-foreground mb-6">Our Joint Mission</h2>
            <p className="text-lg text-muted-foreground mb-8">
              Together, Vibra Music and IBCI Fly Wings empower students and creators to achieve their dreams through music and education. We believe in nurturing talent and providing opportunities for growth.
            </p>
            <div className="grid sm:grid-cols-3 gap-6">
              <div className="p-6 bg-card rounded-xl border border-border/50">
                <GraduationCap className="h-10 w-10 text-primary mx-auto mb-4" />
                <h3 className="font-semibold text-foreground mb-2">Talent Development</h3>
                <p className="text-sm text-muted-foreground">Training and mentoring aspiring artists</p>
              </div>
              <div className="p-6 bg-card rounded-xl border border-border/50">
                <Heart className="h-10 w-10 text-primary mx-auto mb-4" />
                <h3 className="font-semibold text-foreground mb-2">Charity Programs</h3>
                <p className="text-sm text-muted-foreground">Supporting underprivileged students</p>
              </div>
              <div className="p-6 bg-card rounded-xl border border-border/50">
                <Music className="h-10 w-10 text-primary mx-auto mb-4" />
                <h3 className="font-semibold text-foreground mb-2">Creative Platform</h3>
                <p className="text-sm text-muted-foreground">Showcasing talent worldwide</p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-foreground mb-4">Get Involved</h2>
            <p className="text-muted-foreground mb-8">
              Students and creators can participate in workshops, talent showcases, and collaborative projects.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button asChild size="lg">
                <Link to="/contact">Contact Us</Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/about">Learn About IBCI</Link>
              </Button>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}
