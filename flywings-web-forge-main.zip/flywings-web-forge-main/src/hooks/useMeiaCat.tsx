import { useState } from "react";

interface MeiaMessage {
  section: string;
  message: string;
}

const meiaMessages: Record<string, string> = {
  hero: "Welcome to IBCI! 🎓 I'm Meia, your friendly AI guide. We offer premium professional courses to help you achieve your career goals. Let me show you around!",
  stats: "Look at these impressive numbers! 📊 We have over 5,000 happy students who have successfully completed our courses and advanced their careers. You could be next!",
  courses: "Our courses are designed by industry experts! 📚 Whether you're interested in CA, CS, ACCA, CMA, MBA, or Degree programs, we have something perfect for you.",
  features: "Here's what makes IBCI special! ✨ We provide comprehensive study materials, expert faculty, flexible learning schedules, and 100% placement assistance.",
  charity: "We believe in giving back! 💝 Our charity program 'Give a Little, Change a Lot' helps provide education to those who need it most. Every contribution makes a difference!",
  ibciPlay: "Check out IBCI Play! 🎥 Access 1000+ hours of premium video content, live classes, and recorded sessions anytime, anywhere. Learning has never been this flexible!",
  placement: "Ready to start your journey? 🚀 Fill out the placement form and our team will get in touch with you soon. Let's build your future together!",
  footer: "Need more information? 📞 You can find all our contact details, social media links, and useful resources here. I'm always here to help!",
};

export const useMeiaCat = () => {
  const [showMeia, setShowMeia] = useState(false);
  const [currentMessage, setCurrentMessage] = useState("");

  const triggerMeia = (section: keyof typeof meiaMessages) => {
    const message = meiaMessages[section];
    if (message) {
      setCurrentMessage(message);
      setShowMeia(true);
    }
  };

  const hideMeia = () => {
    setShowMeia(false);
  };

  return {
    showMeia,
    currentMessage,
    triggerMeia,
    hideMeia,
  };
};
