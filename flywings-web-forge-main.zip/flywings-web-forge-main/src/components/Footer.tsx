import { Facebook, Instagram, Youtube, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

const motivationalQuotes = [
  "Your wings already exist. All you have to do is fly.",
  "Success is not the key to happiness. Happiness is the key to success.",
  "The future belongs to those who believe in the beauty of their dreams.",
  "Excellence is not a skill, it's an attitude.",
  "Rise beyond limits. Soar beyond expectations.",
];

export const Footer = () => {
  const currentQuote = motivationalQuotes[Math.floor(Math.random() * motivationalQuotes.length)];

  return (
    <footer className="bg-primary text-primary-foreground">
      {/* Motivational Quote Banner */}
      <div className="bg-accent py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-lg font-medium text-accent-foreground italic">
            "{currentQuote}"
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and Description */}
          <div className="md:col-span-2">
            <img
              src="/lovable-uploads/8431a970-c51d-4428-8e2a-35b4eed0b7c5.png"
              alt="IBCI Fly Wings Logo"
              className="h-16 w-auto mb-4"
            />
            <p className="text-primary-foreground/80 mb-4">
              IBCI Fly Wings provides world-class online coaching for professional courses 
              including CA, CMA, ACCA, CS, MBA, and Degree programs. Rise beyond limits with us.
            </p>
            <div className="flex space-x-4">
              <Button variant="ghost" size="icon" className="text-primary-foreground hover:text-accent">
                <Facebook className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-primary-foreground hover:text-accent">
                <Instagram className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-primary-foreground hover:text-accent">
                <Youtube className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-primary-foreground hover:text-accent">
                <MessageCircle className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="/about" className="text-primary-foreground/80 hover:text-accent transition-colors">About Us</a></li>
              <li><a href="/courses" className="text-primary-foreground/80 hover:text-accent transition-colors">Courses</a></li>
              <li><a href="/live-classes" className="text-primary-foreground/80 hover:text-accent transition-colors">Live Classes</a></li>
              <li><a href="/contact" className="text-primary-foreground/80 hover:text-accent transition-colors">Contact</a></li>
              <li><a href="/login" className="text-primary-foreground/80 hover:text-accent transition-colors">Student Login</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Info</h3>
            <div className="space-y-2 text-primary-foreground/80">
              <p>📧 info@ibciflywings.com</p>
              <p>📱 +91 XXXXX XXXXX</p>
              <p>🕒 Mon-Sat: 9:00 AM - 6:00 PM</p>
            </div>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 mt-8 pt-8 text-center">
          <p className="text-primary-foreground/60">
            © 2024 IBCI Fly Wings. All rights reserved. | Empowering dreams, building futures.
          </p>
        </div>
      </div>
    </footer>
  );
};