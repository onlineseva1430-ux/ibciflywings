import { Card, CardContent } from "@/components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import Autoplay from "embla-carousel-autoplay";
import caAd from "@/assets/course-ad-ca.jpg";
import cmaAd from "@/assets/course-ad-cma.jpg";
import accaAd from "@/assets/course-ad-acca.jpg";
import mbaAd from "@/assets/course-ad-mba.jpg";
import csAd from "@/assets/course-ad-cs.jpg";
import degreeAd from "@/assets/course-ad-degree.jpg";

const courseAds = [
  {
    image: caAd,
    title: "CA - Chartered Accountancy",
    description: "Master financial accounting, taxation, and auditing with India's most prestigious professional qualification."
  },
  {
    image: cmaAd,
    title: "CMA - Cost & Management Accountancy",
    description: "Become a cost management expert with comprehensive training in financial planning and strategic management."
  },
  {
    image: accaAd,
    title: "ACCA - Global Accounting",
    description: "Achieve international recognition with ACCA certification and unlock global career opportunities."
  },
  {
    image: mbaAd,
    title: "MBA - Business Administration",
    description: "Transform into a business leader with our comprehensive MBA program covering all aspects of management."
  },
  {
    image: csAd,
    title: "CS - Company Secretary",
    description: "Excel in corporate governance, compliance, and legal affairs with our expert-led CS program."
  },
  {
    image: degreeAd,
    title: "Degree Programs",
    description: "Build a strong academic foundation with our diverse range of degree programs tailored to your goals."
  }
];

export const CourseCarousel = () => {
  return (
    <Carousel
      opts={{
        align: "start",
        loop: true,
      }}
      plugins={[
        Autoplay({
          delay: 4000,
        }),
      ]}
      className="w-full"
    >
      <CarouselContent>
        {courseAds.map((course, index) => (
          <CarouselItem key={index} className="md:basis-1/2 lg:basis-1/3">
            <div className="p-1">
              <Card className="overflow-hidden group hover:shadow-xl transition-all duration-300">
                <CardContent className="p-0">
                  <div className="relative overflow-hidden">
                    <img
                      src={course.image}
                      alt={course.title}
                      className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-primary/90 via-primary/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                      <div className="p-6 text-primary-foreground">
                        <h3 className="font-bold text-xl mb-2">{course.title}</h3>
                        <p className="text-sm">{course.description}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </CarouselItem>
        ))}
      </CarouselContent>
      <CarouselPrevious className="left-2" />
      <CarouselNext className="right-2" />
    </Carousel>
  );
};
