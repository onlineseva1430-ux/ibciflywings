import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Plus, Edit2, Trash2, Save, ExternalLink, FileText } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface CmsPage {
  id: string;
  slug: string;
  title: string;
  subtitle: string | null;
  content: string | null;
  meta_description: string | null;
  image_url: string | null;
  is_published: boolean;
  display_order: number;
}

export function AdminPagesTab() {
  const { toast } = useToast();
  const [pages, setPages] = useState<CmsPage[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingPage, setEditingPage] = useState<CmsPage | null>(null);

  useEffect(() => {
    fetchPages();
  }, []);

  const fetchPages = async () => {
    const { data, error } = await supabase
      .from("cms_pages")
      .select("*")
      .order("display_order");

    if (data) setPages(data);
    setLoading(false);
  };

  const savePage = async (page: CmsPage) => {
    if (page.id) {
      // Update existing
      const { error } = await supabase
        .from("cms_pages")
        .update({
          title: page.title,
          subtitle: page.subtitle,
          content: page.content,
          meta_description: page.meta_description,
          image_url: page.image_url,
          is_published: page.is_published,
          display_order: page.display_order
        })
        .eq("id", page.id);

      if (error) {
        toast({ title: "Error", description: "Failed to update page", variant: "destructive" });
      } else {
        toast({ title: "Success", description: "Page updated successfully" });
      }
    } else {
      // Create new
      const { error } = await supabase
        .from("cms_pages")
        .insert([{
          slug: page.slug,
          title: page.title,
          subtitle: page.subtitle,
          content: page.content,
          meta_description: page.meta_description,
          image_url: page.image_url,
          is_published: page.is_published,
          display_order: page.display_order
        }]);

      if (error) {
        toast({ title: "Error", description: error.message, variant: "destructive" });
      } else {
        toast({ title: "Success", description: "Page created successfully" });
      }
    }
    fetchPages();
    setEditingPage(null);
  };

  const deletePage = async (id: string) => {
    const { error } = await supabase.from("cms_pages").delete().eq("id", id);
    if (!error) {
      toast({ title: "Success", description: "Page deleted" });
      fetchPages();
    }
  };

  const createNewPage = () => {
    setEditingPage({
      id: '',
      slug: '',
      title: '',
      subtitle: '',
      content: '',
      meta_description: '',
      image_url: '',
      is_published: true,
      display_order: pages.length
    });
  };

  if (loading) {
    return <div className="flex justify-center py-8">Loading...</div>;
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Vibra Pages Management
            </CardTitle>
            <CardDescription>
              Create and edit pages for About Vibra, Terms, Privacy, Help & Partners
            </CardDescription>
          </div>
          <Button onClick={createNewPage}>
            <Plus className="h-4 w-4 mr-2" /> Add Page
          </Button>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Page</TableHead>
                <TableHead>Slug</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Order</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pages.map((page) => (
                <TableRow key={page.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{page.title}</div>
                      <div className="text-sm text-muted-foreground line-clamp-1">{page.subtitle}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <code className="text-xs bg-muted px-2 py-1 rounded">/vibra/{page.slug}</code>
                  </TableCell>
                  <TableCell>
                    <Badge variant={page.is_published ? "default" : "secondary"}>
                      {page.is_published ? "Published" : "Draft"}
                    </Badge>
                  </TableCell>
                  <TableCell>{page.display_order}</TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button variant="ghost" size="sm" onClick={() => setEditingPage(page)}>
                        <Edit2 className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm" asChild>
                        <a href={`/vibra/${page.slug}`} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4" />
                        </a>
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => deletePage(page.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={!!editingPage} onOpenChange={() => setEditingPage(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingPage?.id ? 'Edit Page' : 'Create New Page'}</DialogTitle>
            <DialogDescription>
              {editingPage?.id ? 'Update the page content below' : 'Fill in the details for your new page'}
            </DialogDescription>
          </DialogHeader>
          {editingPage && (
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Title</Label>
                  <Input
                    value={editingPage.title}
                    onChange={(e) => setEditingPage({ ...editingPage, title: e.target.value })}
                    placeholder="Page title"
                  />
                </div>
                <div className="space-y-2">
                  <Label>URL Slug</Label>
                  <Input
                    value={editingPage.slug}
                    onChange={(e) => setEditingPage({ ...editingPage, slug: e.target.value.toLowerCase().replace(/\s+/g, '-') })}
                    placeholder="page-slug"
                    disabled={!!editingPage.id}
                  />
                  <p className="text-xs text-muted-foreground">URL: /vibra/{editingPage.slug || 'page-slug'}</p>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Subtitle</Label>
                <Input
                  value={editingPage.subtitle || ''}
                  onChange={(e) => setEditingPage({ ...editingPage, subtitle: e.target.value })}
                  placeholder="Brief description shown under the title"
                />
              </div>

              <div className="space-y-2">
                <Label>Content</Label>
                <Textarea
                  value={editingPage.content || ''}
                  onChange={(e) => setEditingPage({ ...editingPage, content: e.target.value })}
                  placeholder="Page content (use ## for headings, - for bullet points)"
                  rows={12}
                  className="font-mono text-sm"
                />
                <p className="text-xs text-muted-foreground">
                  Formatting: Use ## for headings, - for bullet lists, 1. for numbered lists
                </p>
              </div>

              <div className="space-y-2">
                <Label>Meta Description (SEO)</Label>
                <Input
                  value={editingPage.meta_description || ''}
                  onChange={(e) => setEditingPage({ ...editingPage, meta_description: e.target.value })}
                  placeholder="Brief description for search engines"
                  maxLength={160}
                />
              </div>

              <div className="space-y-2">
                <Label>Image URL (optional)</Label>
                <Input
                  value={editingPage.image_url || ''}
                  onChange={(e) => setEditingPage({ ...editingPage, image_url: e.target.value })}
                  placeholder="https://example.com/image.jpg"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Display Order</Label>
                  <Input
                    type="number"
                    value={editingPage.display_order}
                    onChange={(e) => setEditingPage({ ...editingPage, display_order: parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div className="flex items-center justify-between pt-6">
                  <Label>Published</Label>
                  <Switch
                    checked={editingPage.is_published}
                    onCheckedChange={(checked) => setEditingPage({ ...editingPage, is_published: checked })}
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button variant="outline" onClick={() => setEditingPage(null)}>
                  Cancel
                </Button>
                <Button onClick={() => savePage(editingPage)}>
                  <Save className="h-4 w-4 mr-2" /> Save Page
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
