import { ReactNode, useState } from "react";
import { Volume2 } from "lucide-react";
import { useMeia } from "@/contexts/MeiaContext";
import { Button } from "./ui/button";

interface ReadableSectionProps {
  children: ReactNode;
  content: string;
  sectionName?: string;
}

export const ReadableSection = ({ children, content, sectionName }: ReadableSectionProps) => {
  const { readContent } = useMeia();
  const [isHovered, setIsHovered] = useState(false);

  const handleRead = (e: React.MouseEvent) => {
    e.stopPropagation();
    const textToRead = sectionName 
      ? `${sectionName} section: ${content}`
      : content;
    readContent(textToRead);
  };

  return (
    <div 
      className="relative group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {children}
      {isHovered && (
        <Button
          size="icon"
          variant="secondary"
          className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity shadow-lg z-10"
          onClick={handleRead}
          aria-label={`Read ${sectionName || 'content'} aloud`}
        >
          <Volume2 className="h-4 w-4" />
        </Button>
      )}
    </div>
  );
};
