import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Heart, Mail, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export const CharityProgramSection = () => {
  const { toast } = useToast();
  const [showSuccess, setShowSuccess] = useState(false);
  const [declarationChecked, setDeclarationChecked] = useState(false);
  const [formData, setFormData] = useState({
    fullName: "",
    dateOfBirth: "",
    contactNumber: "",
    email: "",
    address: "",
    guardianName: "",
    familyIncome: "",
    courseInterested: "",
    lastQualification: "",
    institutionName: "",
    reasonForSupport: "",
    incomeProof: null as File | null,
    idProof: null as File | null,
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, field: 'incomeProof' | 'idProof') => {
    const file = e.target.files?.[0] || null;
    setFormData(prev => ({ ...prev, [field]: file }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!declarationChecked) {
      toast({
        title: "Declaration Required",
        description: "Please accept the declaration to submit the application.",
        variant: "destructive",
      });
      return;
    }

    // Here you would typically send the data to your backend
    console.log("Charity application submitted:", formData);
    
    setShowSuccess(true);
    toast({
      title: "Application Submitted Successfully! 🌟",
      description: "We will review your application and contact you soon.",
    });

    // Reset form
    setFormData({
      fullName: "",
      dateOfBirth: "",
      contactNumber: "",
      email: "",
      address: "",
      guardianName: "",
      familyIncome: "",
      courseInterested: "",
      lastQualification: "",
      institutionName: "",
      reasonForSupport: "",
      incomeProof: null,
      idProof: null,
    });
    setDeclarationChecked(false);
  };

  return (
    <>
      <section className="py-20 bg-gradient-to-br from-primary/5 via-accent/5 to-primary/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Charity Message */}
          <div className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground p-8 md:p-12 rounded-2xl shadow-2xl mb-12 border-4 border-accent/20">
            <div className="text-center mb-8">
              <Heart className="h-16 w-16 mx-auto mb-4 text-accent animate-pulse" />
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                🌟 IBCI Fly Wings — Empowering Dreams Through Education 🌟
              </h2>
            </div>
            
            <div className="space-y-6 text-lg leading-relaxed max-w-5xl mx-auto">
              <p className="text-center font-semibold text-xl">
                At IBCI Fly Wings, we believe that every dream deserves a chance to fly — regardless of financial limits.
              </p>
              
              <p>
                Our institution is not only dedicated to providing quality education and professional training for courses like <strong>CA, CMA, CS, ACCA, and MBA</strong>, but also deeply committed to uplifting financially challenged students through our <strong>charitable education initiative</strong>.
              </p>
              
              <p>
                Through this noble effort, IBCI Fly Wings funds and supports students from economically weaker sections, ensuring that no talented mind is left behind due to lack of money. We proudly stand for equal access to professional education, creating opportunities for deserving students to rise beyond limits and achieve their dreams with dignity.
              </p>
              
              <p className="text-center font-bold text-xl mt-8 text-accent">
                💛 Together, let's build a future where education is a right — not a privilege.
              </p>
            </div>
          </div>

          {/* Application Form */}
          <Card className="shadow-2xl border-2 border-primary/20">
            <CardHeader className="bg-gradient-to-r from-primary/10 to-accent/10">
              <CardTitle className="text-3xl text-center flex items-center justify-center gap-3">
                <Heart className="h-8 w-8 text-primary" />
                Apply for Charity Program
              </CardTitle>
              <p className="text-center text-muted-foreground mt-2">
                Fill out this form to apply for educational assistance
              </p>
            </CardHeader>
            <CardContent className="p-6 md:p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Full Name */}
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Full Name *</Label>
                    <Input
                      id="fullName"
                      name="fullName"
                      value={formData.fullName}
                      onChange={handleInputChange}
                      required
                      placeholder="Enter your full name"
                    />
                  </div>

                  {/* Date of Birth */}
                  <div className="space-y-2">
                    <Label htmlFor="dateOfBirth">Date of Birth *</Label>
                    <Input
                      id="dateOfBirth"
                      name="dateOfBirth"
                      type="date"
                      value={formData.dateOfBirth}
                      onChange={handleInputChange}
                      required
                    />
                  </div>

                  {/* Contact Number */}
                  <div className="space-y-2">
                    <Label htmlFor="contactNumber">Contact Number *</Label>
                    <Input
                      id="contactNumber"
                      name="contactNumber"
                      type="tel"
                      value={formData.contactNumber}
                      onChange={handleInputChange}
                      required
                      placeholder="+91 XXXXXXXXXX"
                    />
                  </div>

                  {/* Email */}
                  <div className="space-y-2">
                    <Label htmlFor="email">Email ID *</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      placeholder="your.email@example.com"
                    />
                  </div>

                  {/* Guardian's Name */}
                  <div className="space-y-2">
                    <Label htmlFor="guardianName">Guardian's Name *</Label>
                    <Input
                      id="guardianName"
                      name="guardianName"
                      value={formData.guardianName}
                      onChange={handleInputChange}
                      required
                      placeholder="Parent/Guardian name"
                    />
                  </div>

                  {/* Family Annual Income */}
                  <div className="space-y-2">
                    <Label htmlFor="familyIncome">Family Annual Income *</Label>
                    <Input
                      id="familyIncome"
                      name="familyIncome"
                      value={formData.familyIncome}
                      onChange={handleInputChange}
                      required
                      placeholder="₹ XXXXX"
                    />
                  </div>

                  {/* Course Interested In */}
                  <div className="space-y-2">
                    <Label htmlFor="courseInterested">Course Interested In *</Label>
                    <Select
                      value={formData.courseInterested}
                      onValueChange={(value) => setFormData(prev => ({ ...prev, courseInterested: value }))}
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select a course" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="CA">CA - Chartered Accountant</SelectItem>
                        <SelectItem value="CMA">CMA - Cost & Management Accountant</SelectItem>
                        <SelectItem value="CS">CS - Company Secretary</SelectItem>
                        <SelectItem value="ACCA">ACCA</SelectItem>
                        <SelectItem value="MBA">MBA</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Educational Qualification */}
                  <div className="space-y-2">
                    <Label htmlFor="lastQualification">Educational Qualification *</Label>
                    <Input
                      id="lastQualification"
                      name="lastQualification"
                      value={formData.lastQualification}
                      onChange={handleInputChange}
                      required
                      placeholder="Last passed exam (e.g., 12th, Graduation)"
                    />
                  </div>

                  {/* Institution Name */}
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="institutionName">Institution / School Name *</Label>
                    <Input
                      id="institutionName"
                      name="institutionName"
                      value={formData.institutionName}
                      onChange={handleInputChange}
                      required
                      placeholder="Name of your school/college"
                    />
                  </div>

                  {/* Permanent Address */}
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="address">Permanent Address *</Label>
                    <Textarea
                      id="address"
                      name="address"
                      value={formData.address}
                      onChange={handleInputChange}
                      required
                      placeholder="Enter your complete address"
                      rows={3}
                    />
                  </div>

                  {/* Reason for Financial Support */}
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="reasonForSupport">Reason for Financial Support *</Label>
                    <Textarea
                      id="reasonForSupport"
                      name="reasonForSupport"
                      value={formData.reasonForSupport}
                      onChange={handleInputChange}
                      required
                      placeholder="Please explain why you need financial assistance (short explanation)"
                      rows={4}
                    />
                  </div>

                  {/* Income Proof Upload */}
                  <div className="space-y-2">
                    <Label htmlFor="incomeProof">Upload Proof of Income (Optional)</Label>
                    <Input
                      id="incomeProof"
                      name="incomeProof"
                      type="file"
                      onChange={(e) => handleFileChange(e, 'incomeProof')}
                      accept=".pdf,.jpg,.jpeg,.png"
                    />
                    <p className="text-xs text-muted-foreground">PDF, JPG, or PNG (Max 5MB)</p>
                  </div>

                  {/* ID Proof Upload */}
                  <div className="space-y-2">
                    <Label htmlFor="idProof">Upload ID Proof *</Label>
                    <Input
                      id="idProof"
                      name="idProof"
                      type="file"
                      onChange={(e) => handleFileChange(e, 'idProof')}
                      accept=".pdf,.jpg,.jpeg,.png"
                      required
                    />
                    <p className="text-xs text-muted-foreground">Aadhaar/School ID (PDF, JPG, PNG - Max 5MB)</p>
                  </div>
                </div>

                {/* Declaration Checkbox */}
                <div className="flex items-start space-x-3 p-4 bg-muted/50 rounded-lg">
                  <Checkbox
                    id="declaration"
                    checked={declarationChecked}
                    onCheckedChange={(checked) => setDeclarationChecked(checked as boolean)}
                    required
                  />
                  <Label htmlFor="declaration" className="text-sm leading-relaxed cursor-pointer">
                    <strong>Declaration:</strong> I declare that the above information is true to the best of my knowledge. *
                  </Label>
                </div>

                {/* Submit Button */}
                <div className="text-center pt-4">
                  <Button
                    type="submit"
                    size="lg"
                    className="relative overflow-hidden group bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 px-12 transition-all duration-300 hover:scale-105 hover:shadow-xl"
                  >
                    <Send className="mr-2 h-5 w-5 group-hover:animate-bounce-subtle" />
                    <span className="relative z-10">Submit Application</span>
                    <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-0 group-hover:opacity-100 group-hover:animate-shimmer"></span>
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <div className="mt-12 text-center">
            <h3 className="text-2xl font-bold mb-6">Contact Us</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-center gap-2">
                    <Mail className="h-5 w-5 text-primary" />
                    Official IBCI Fly Wings
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <a 
                    href="mailto:ibciflywings@gmail.com" 
                    className="text-primary hover:underline font-medium"
                  >
                    ibciflywings@gmail.com
                  </a>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-center gap-2">
                    <Mail className="h-5 w-5 text-primary" />
                    MD & Proprietor
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-1">Faize</p>
                  <a 
                    href="mailto:trustibciflywings@gmail.com" 
                    className="text-primary hover:underline font-medium"
                  >
                    trustibciflywings@gmail.com
                  </a>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Success Dialog */}
      <Dialog open={showSuccess} onOpenChange={setShowSuccess}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-center text-2xl">
              <Heart className="h-12 w-12 mx-auto mb-4 text-primary" />
              Application Submitted Successfully! 🌟
            </DialogTitle>
            <DialogDescription className="text-center space-y-4 pt-4">
              <p className="text-lg">
                Thank you for applying to the IBCI Fly Wings Charity Program.
              </p>
              <p>
                We will carefully review your application and get back to you soon. Our team is committed to helping deserving students achieve their dreams.
              </p>
              <p className="font-semibold text-primary">
                Rise Beyond Limits! 🦅
              </p>
            </DialogDescription>
          </DialogHeader>
          <div className="text-center mt-4">
            <Button onClick={() => setShowSuccess(false)}>Close</Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};
