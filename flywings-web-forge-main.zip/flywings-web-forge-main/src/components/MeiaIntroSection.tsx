import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { MessageCircle, Sparkles, BookOpen, Heart } from "lucide-react";
import meiaCat from "@/assets/meia-cat.png";
import { MeiaChatDialog } from "./MeiaChatDialog";

export const MeiaIntroSection = () => {
  const [isChatOpen, setIsChatOpen] = useState(false);

  return (
    <>
      <section className="py-20 px-4 bg-gradient-to-br from-primary/5 via-accent/5 to-background relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi02LTIuNjg2LTYtNiAyLjY4Ni02IDYtNnptMCAxMmMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi02LTIuNjg2LTYtNiAyLjY4Ni02IDYtNnpNMTggMThjMy4zMTQgMCA2IDIuNjg2IDYgNnMtMi42ODYgNi02IDYtNi0yLjY4Ni02LTYgMi42ODYtNiA2LTZ6bTAgMTJjMy4zMTQgMCA2IDIuNjg2IDYgNnMtMi42ODYgNi02IDYtNi0yLjY4Ni02LTYgMi42ODYtNiA2LTZ6IiBmaWxsPSIjMDAwIiBvcGFjaXR5PSIuMDMiLz48L2c+PC9zdmc+')] opacity-50"></div>
        
        <div className="max-w-6xl mx-auto relative z-10">
          <div className="text-center mb-12 animate-fade-in-up">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Meet Meia - Your AI Companion
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              I'm here to guide you through your educational journey! 🐱✨
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 items-center">
            {/* Meia's Image and Intro */}
            <div className="flex justify-center animate-fade-in-up [animation-delay:200ms]">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-accent/20 rounded-full blur-3xl animate-pulse-glow"></div>
                <img 
                  src={meiaCat} 
                  alt="Meia AI Assistant" 
                  className="relative w-64 h-64 object-contain drop-shadow-2xl animate-float"
                />
              </div>
            </div>

            {/* Meia's Self Introduction */}
            <div className="space-y-6 animate-fade-in-up [animation-delay:400ms]">
              <Card className="p-6 border-2 border-primary/20 bg-card/50 backdrop-blur-sm">
                <div className="flex items-start gap-3 mb-4">
                  <Sparkles className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold text-xl mb-2">Hi, I'm Meia! 👋</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      I'm your friendly AI cat assistant, purr-fectly designed to help you navigate through IBCI Fly Wings! 
                      Whether you're curious about our courses, need study tips, or just want to chat about your career goals, 
                      I'm here 24/7 with a warm welcome and helpful guidance!
                    </p>
                  </div>
                </div>
              </Card>

              <div className="grid grid-cols-2 gap-4">
                <Card className="p-4 text-center hover:shadow-lg transition-shadow">
                  <MessageCircle className="h-8 w-8 text-primary mx-auto mb-2" />
                  <h4 className="font-semibold mb-1">Ask Me Anything</h4>
                  <p className="text-sm text-muted-foreground">Course details, enrollment, & more</p>
                </Card>

                <Card className="p-4 text-center hover:shadow-lg transition-shadow">
                  <BookOpen className="h-8 w-8 text-accent mx-auto mb-2" />
                  <h4 className="font-semibold mb-1">Study Guidance</h4>
                  <p className="text-sm text-muted-foreground">Tips & motivation for success</p>
                </Card>

                <Card className="p-4 text-center hover:shadow-lg transition-shadow">
                  <Sparkles className="h-8 w-8 text-primary mx-auto mb-2" />
                  <h4 className="font-semibold mb-1">Platform Help</h4>
                  <p className="text-sm text-muted-foreground">Navigate features easily</p>
                </Card>

                <Card className="p-4 text-center hover:shadow-lg transition-shadow">
                  <Heart className="h-8 w-8 text-accent mx-auto mb-2" />
                  <h4 className="font-semibold mb-1">Always Here</h4>
                  <p className="text-sm text-muted-foreground">24/7 support & care</p>
                </Card>
              </div>

              <Button 
                size="lg" 
                className="w-full group relative overflow-hidden"
                onClick={() => setIsChatOpen(true)}
              >
                <span className="relative z-10 flex items-center justify-center gap-2">
                  <MessageCircle className="h-5 w-5 group-hover:animate-bounce-subtle" />
                  Start Chatting with Meia
                </span>
                <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-0 group-hover:opacity-100 group-hover:animate-shimmer"></span>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <MeiaChatDialog open={isChatOpen} onOpenChange={setIsChatOpen} />

      {/* Floating Meia Button */}
      <Button
        size="icon"
        className="fixed bottom-8 right-8 h-16 w-16 rounded-full shadow-2xl z-50 animate-float hover:scale-110 transition-transform"
        onClick={() => setIsChatOpen(true)}
      >
        <img src={meiaCat} alt="Chat with Meia" className="w-10 h-10 rounded-full" />
      </Button>
    </>
  );
};
