import { useState, useEffect, useRef } from "react";
import { X, Volume2, VolumeX } from "lucide-react";
import meiaCat from "@/assets/meia-cat.png";
import { Button } from "@/components/ui/button";

interface MeiaCatProps {
  message: string;
  onClose: () => void;
}

export const MeiaCat = ({ message, onClose }: MeiaCatProps) => {
  const [isVisible, setIsVisible] = useState(false);
  const [currentMessage, setCurrentMessage] = useState("");
  const [messageIndex, setMessageIndex] = useState(0);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const synthRef = useRef<SpeechSynthesis | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      synthRef.current = window.speechSynthesis;
    }
    
    return () => {
      if (synthRef.current) {
        synthRef.current.cancel();
      }
    };
  }, []);

  useEffect(() => {
    setIsVisible(true);
    setCurrentMessage("");
    setMessageIndex(0);
    
    // Stop any ongoing speech when new message arrives
    if (synthRef.current) {
      synthRef.current.cancel();
      setIsSpeaking(false);
    }
  }, [message]);

  // Typing animation effect
  useEffect(() => {
    if (messageIndex < message.length) {
      const timeout = setTimeout(() => {
        setCurrentMessage(prev => prev + message[messageIndex]);
        setMessageIndex(prev => prev + 1);
      }, 30);
      return () => clearTimeout(timeout);
    } else if (messageIndex === message.length && message.length > 0 && !isSpeaking) {
      // Start speaking when typing is complete
      speakMessage();
    }
  }, [messageIndex, message]);

  const speakMessage = () => {
    if (!synthRef.current || !message) return;

    synthRef.current.cancel();
    const utterance = new SpeechSynthesisUtterance(message);
    utterance.rate = 0.9;
    utterance.pitch = 1.1;
    utterance.volume = 1;
    
    // Try to use a female voice
    const voices = synthRef.current.getVoices();
    const femaleVoice = voices.find(voice => 
      voice.name.includes('Female') || voice.name.includes('Samantha') || voice.name.includes('Victoria')
    ) || voices[0];
    
    if (femaleVoice) {
      utterance.voice = femaleVoice;
    }

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    synthRef.current.speak(utterance);
  };

  const toggleSpeech = () => {
    if (!synthRef.current) return;

    if (isSpeaking) {
      synthRef.current.cancel();
      setIsSpeaking(false);
    } else {
      speakMessage();
    }
  };

  return (
    <div className={`fixed bottom-8 right-8 z-50 transition-all duration-500 ${
      isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
    }`}>
      {/* Speech Bubble */}
      <div className="relative mb-4 mr-4 bg-card border-2 border-primary/30 rounded-2xl p-4 shadow-premium max-w-sm animate-slide-up">
        <div className="flex items-center gap-2 mb-2">
          <button
            onClick={onClose}
            className="absolute -top-2 -right-2 bg-primary text-primary-foreground rounded-full p-1 hover:scale-110 transition-transform"
          >
            <X className="w-4 h-4" />
          </button>
          <Button
            size="icon"
            variant="ghost"
            onClick={toggleSpeech}
            className="h-6 w-6"
          >
            {isSpeaking ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
          </Button>
          <div className="font-semibold text-primary text-sm">Meia says:</div>
        </div>
        <p className="text-sm mt-2 text-foreground leading-relaxed">{currentMessage}</p>
        {/* Speech bubble tail */}
        <div className="absolute -bottom-2 right-12 w-4 h-4 bg-card border-r-2 border-b-2 border-primary/30 transform rotate-45"></div>
      </div>

      {/* Cat Character */}
      <div className="relative animate-float">
        <div className="relative w-32 h-32 cursor-pointer hover:scale-110 transition-transform duration-300">
          <img 
            src={meiaCat} 
            alt="Meia the AI Cat Assistant" 
            className="w-full h-full object-contain drop-shadow-xl animate-glow-pulse"
          />
          {/* Blinking eyes animation overlay */}
          <div className="absolute inset-0 animate-pulse opacity-0 hover:opacity-100 transition-opacity"></div>
        </div>
        {/* Glowing aura */}
        <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-accent/20 rounded-full blur-xl -z-10 animate-pulse-glow"></div>
      </div>
    </div>
  );
};
