import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, Gamepad2, Trophy, Users, Brain, Zap, Shield, Star } from "lucide-react";
import ibciPlayLogo from "@/assets/ibci-play-logo.png";

export const IbciPlaySection = () => {
  const features = [
    {
      icon: <Gamepad2 className="h-6 w-6" />,
      title: "Interactive Learning",
      description: "Up to 30 MCQs per session with instant feedback and explanations"
    },
    {
      icon: <Users className="h-6 w-6" />,
      title: "Multiplayer Mode",
      description: "Join virtual classrooms, compete with peers in real-time"
    },
    {
      icon: <Brain className="h-6 w-6" />,
      title: "AI-Powered Practice",
      description: "Practice offline with intelligent AI that adapts to your level"
    },
    {
      icon: <Trophy className="h-6 w-6" />,
      title: "Gamification",
      description: "Earn points, badges, and climb the leaderboard"
    },
    {
      icon: <Zap className="h-6 w-6" />,
      title: "Dual Roles",
      description: "Play as Student or Teacher - ask questions and guide others"
    },
    {
      icon: <Shield className="h-6 w-6" />,
      title: "Course-Specific",
      description: "Questions strictly from CA, CMA, CPA, MBA syllabi"
    }
  ];

  const courses = ["CA", "CMA", "CPA", "MBA"];

  return (
    <section className="py-20 bg-gradient-to-br from-black via-zinc-950 to-black text-white relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-amber-600/20 to-yellow-600/20 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-amber-600/20 to-yellow-600/20 rounded-full blur-3xl"></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-radial from-amber-600/10 via-transparent to-transparent rounded-full blur-2xl"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-12">
          <Badge className="mb-4 bg-gradient-to-r from-amber-600 to-yellow-600 text-black text-lg px-6 py-2 animate-fade-in shadow-lg shadow-amber-600/50">
            NEW LAUNCH
          </Badge>
          
          <div className="flex justify-center mb-6">
            <img 
              src={ibciPlayLogo} 
              alt="IBCI Play Logo" 
              className="h-32 w-auto animate-fade-in drop-shadow-[0_0_30px_rgba(217,119,6,0.5)]"
            />
          </div>
          
          <h2 className="text-4xl md:text-5xl font-bold mb-4 animate-fade-in bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 bg-clip-text text-transparent drop-shadow-[0_0_20px_rgba(217,119,6,0.5)]">
            IBCI PLAY
          </h2>
          <p className="text-xl md:text-2xl mb-2 text-amber-100 animate-fade-in font-semibold">
            Educational Game Platform
          </p>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto animate-fade-in">
            Transform your professional learning into an engaging, interactive gaming experience
          </p>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Left Column - Key Features */}
          <div>
            <h3 className="text-2xl font-bold mb-6 flex items-center gap-2 text-amber-400">
              <Star className="h-6 w-6 text-amber-500" />
              Key Features
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {features.map((feature, index) => (
                <Card key={index} className="bg-zinc-900/80 backdrop-blur-sm border-amber-600/30 hover:border-amber-500/50 hover:bg-zinc-900 transition-all hover:shadow-lg hover:shadow-amber-600/20">
                  <CardHeader className="pb-3">
                    <div className="flex items-center gap-2 text-amber-500 mb-2">
                      {feature.icon}
                      <CardTitle className="text-base text-amber-100">{feature.title}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-300">{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Right Column - Game Modes & Details */}
          <div>
            <h3 className="text-2xl font-bold mb-6 text-amber-400">How It Works</h3>
            
            {/* Game Modes */}
            <Card className="bg-zinc-900/80 backdrop-blur-sm border-amber-600/30 mb-6 hover:border-amber-500/50 transition-all">
              <CardHeader>
                <CardTitle className="text-amber-100 flex items-center gap-2">
                  <Users className="h-5 w-5 text-amber-500" />
                  Online Multiplayer Mode
                </CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300 space-y-2">
                <p>• Join virtual classrooms anytime, anywhere</p>
                <p>• <strong className="text-amber-400">Student Role:</strong> Answer MCQs, earn points & badges</p>
                <p>• <strong className="text-amber-400">Teacher Role:</strong> Create questions and guide peers</p>
                <p>• Real-time leaderboard rankings</p>
                <p>• Form study groups and compete in challenges</p>
              </CardContent>
            </Card>

            <Card className="bg-zinc-900/80 backdrop-blur-sm border-amber-600/30 mb-6 hover:border-amber-500/50 transition-all">
              <CardHeader>
                <CardTitle className="text-amber-100 flex items-center gap-2">
                  <Brain className="h-5 w-5 text-amber-500" />
                  Offline AI Mode
                </CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300 space-y-2">
                <p>• Practice even without internet connection</p>
                <p>• AI-powered questions from your chosen subject</p>
                <p>• Interactive feedback and explanations</p>
                <p>• Continue learning anywhere, anytime</p>
              </CardContent>
            </Card>

            {/* Scoring System */}
            <Card className="bg-gradient-to-br from-amber-900/40 to-yellow-900/40 backdrop-blur-sm border-amber-500/50 shadow-lg shadow-amber-600/20">
              <CardHeader>
                <CardTitle className="text-amber-100 flex items-center gap-2">
                  <Trophy className="h-5 w-5 text-amber-400" />
                  Scoring System
                </CardTitle>
              </CardHeader>
              <CardContent className="text-gray-200 space-y-2">
                <p>• 30 questions per session</p>
                <p>• <strong className="text-amber-300">Wrong answer:</strong> -0.25 points (negative marking)</p>
                <p>• Track your progress with performance dashboard</p>
                <p>• Earn achievements and unlock rewards</p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Supported Courses */}
        <div className="text-center mb-8">
          <h3 className="text-xl font-semibold mb-4 text-amber-400">Supported Professional Courses</h3>
          <div className="flex flex-wrap justify-center gap-3">
            {courses.map((course) => (
              <Badge key={course} className="text-lg px-6 py-2 bg-gradient-to-r from-amber-600 to-yellow-600 text-black shadow-lg shadow-amber-600/30 hover:shadow-amber-600/50 transition-all">
                {course}
              </Badge>
            ))}
          </div>
          <p className="text-sm text-gray-400 mt-3">
            Questions strictly based on official syllabi - ICAI, ICMAI, AICPA approved
          </p>
        </div>

        {/* Additional Features */}
        <Card className="bg-zinc-900/80 backdrop-blur-sm border-amber-600/30 mb-8 hover:border-amber-500/50 transition-all">
          <CardHeader>
            <CardTitle className="text-amber-100 text-center text-xl">Additional Features</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-gray-300">
              <div className="space-y-2">
                <p>✨ <strong className="text-amber-400">Customization:</strong> Design your avatar and classroom</p>
                <p>✨ <strong className="text-amber-400">Progress Tracking:</strong> Detailed performance analytics</p>
                <p>✨ <strong className="text-amber-400">Social Learning:</strong> Share progress with friends</p>
              </div>
              <div className="space-y-2">
                <p>✨ <strong className="text-amber-400">Question Variety:</strong> MCQs, True/False, Fill-in-blanks</p>
                <p>✨ <strong className="text-amber-400">Theme Options:</strong> Dark/Light mode for comfortable studying</p>
                <p>✨ <strong className="text-amber-400">Interactive Feedback:</strong> Detailed explanations for each answer</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* CTA */}
        <div className="text-center">
          <h3 className="text-2xl font-bold mb-4 bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-500 bg-clip-text text-transparent">
            Ready to Make Learning Fun?
          </h3>
          <p className="text-lg text-gray-300 mb-6 max-w-2xl mx-auto">
            Download IBCI PLAY now and transform your professional exam preparation into an exciting, gamified learning experience!
          </p>
          <Button 
            size="lg" 
            className="relative overflow-hidden group bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-500 hover:to-yellow-500 text-black text-xl px-12 py-6 shadow-lg shadow-amber-600/50 hover:shadow-amber-500/70 transition-all duration-300 hover:scale-110 animate-pulse-glow font-bold"
            asChild
          >
            <a 
              href="https://ibci-play-pro-gamified.lovable.app/splash" 
              target="_blank" 
              rel="noopener noreferrer"
              className="relative z-10 flex items-center"
            >
              <Download className="mr-3 h-6 w-6 group-hover:animate-bounce-subtle" />
              <span className="relative z-10">Download IBCI PLAY Now</span>
              <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent opacity-0 group-hover:opacity-100 group-hover:animate-shimmer"></span>
            </a>
          </Button>
          <p className="text-sm text-gray-400 mt-4">
            Available for Android & iOS • Free to Download
          </p>
        </div>
      </div>
    </section>
  );
};
