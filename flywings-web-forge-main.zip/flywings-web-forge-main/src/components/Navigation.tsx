import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import ibciLogo from "@/assets/ibci-logo.png";
import { cn } from "@/lib/utils";

export const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const mainNavigation = [
    { name: "Home", href: "/" },
    { name: "Courses", href: "/courses" },
  ];

  const isActive = (href: string) => location.pathname === href;

  return (
    <nav className="bg-background shadow-sm sticky top-0 z-50 border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <Link to="/" className="flex items-center group">
              <div className="relative">
                <img
                  src={ibciLogo}
                  alt="IBCI Fly Wings Logo"
                  className="h-14 w-14 rounded-full object-cover ring-2 ring-primary/20 group-hover:ring-primary/40 transition-all duration-300"
                />
              </div>
              <div className="ml-3 hidden sm:block">
                <h1 className="text-foreground font-heading font-bold text-lg tracking-tight">
                  IBCI FLY WINGS
                </h1>
                <p className="text-muted-foreground text-xs tracking-wider">Rise Beyond Limits</p>
              </div>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {mainNavigation.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className={cn(
                  "text-sm font-medium transition-colors hover:text-primary",
                  isActive(item.href) 
                    ? "text-primary" 
                    : "text-muted-foreground"
                )}
              >
                {item.name}
              </Link>
            ))}
          </div>

          {/* Login Button */}
          <div className="hidden md:flex items-center">
            <Button 
              asChild
              className="bg-accent hover:bg-accent/90 text-accent-foreground font-medium px-6 rounded-full shadow-md hover:shadow-lg transition-all duration-300"
            >
              <Link to="/signup">Login</Link>
            </Button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-foreground"
                >
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent className="w-72 bg-background">
                <div className="flex flex-col h-full">
                  <div className="flex items-center gap-3 pb-6 border-b">
                    <img src={ibciLogo} alt="IBCI" className="h-12 w-12 rounded-full" />
                    <div>
                      <h2 className="font-heading font-bold text-lg">IBCI Fly Wings</h2>
                      <p className="text-xs text-muted-foreground">Rise Beyond Limits</p>
                    </div>
                  </div>
                  
                  <div className="flex flex-col space-y-2 mt-6 flex-1">
                    {mainNavigation.map((item) => (
                      <Link
                        key={item.name}
                        to={item.href}
                        className={cn(
                          "px-4 py-3 rounded-lg text-base font-medium transition-all",
                          isActive(item.href)
                            ? "bg-primary text-primary-foreground"
                            : "text-foreground hover:bg-muted"
                        )}
                        onClick={() => setIsOpen(false)}
                      >
                        {item.name}
                      </Link>
                    ))}
                  </div>

                  <div className="pt-6 border-t">
                    <Button asChild className="w-full bg-accent hover:bg-accent/90 rounded-full">
                      <Link to="/signup" onClick={() => setIsOpen(false)}>Login</Link>
                    </Button>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
};
