import { Button } from "@/components/ui/button";
import { useMeia } from "@/contexts/MeiaContext";

export const MeiaFloatingButton = () => {
  const { openChat } = useMeia();

  return (
    <Button
      size="icon"
      className="fixed bottom-8 right-8 h-16 w-16 rounded-full z-50 animate-float hover:scale-110 transition-all duration-300 bg-transparent border-0 p-0"
      onClick={openChat}
      aria-label="Chat with AI Assistant"
    >
      {/* 3D Orb Container */}
      <div className="relative w-full h-full">
        {/* Outer glow ring */}
        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-accent/30 to-primary/20 blur-md animate-pulse-glow" />
        
        {/* Main orb */}
        <div className="absolute inset-1 rounded-full bg-gradient-to-br from-accent via-primary to-accent/80 animate-orb-pulse overflow-hidden">
          {/* Inner highlight */}
          <div className="absolute top-1 left-2 w-6 h-4 bg-white/40 rounded-full blur-sm" />
          
          {/* Rotating ring effect */}
          <div className="absolute inset-0 rounded-full border border-white/20 animate-orb-rotate">
            <div className="absolute top-1/2 left-0 w-2 h-2 -translate-y-1/2 -translate-x-1/2 bg-white/60 rounded-full blur-[1px]" />
          </div>
          
          {/* Center glow */}
          <div className="absolute inset-3 rounded-full bg-gradient-to-br from-white/30 via-accent/40 to-transparent" />
          
          {/* AI symbol */}
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-white font-bold text-lg drop-shadow-lg">AI</span>
          </div>
        </div>
        
        {/* Online indicator */}
        <div className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-green-500 rounded-full animate-pulse border-2 border-background shadow-md" />
      </div>
    </Button>
  );
};
